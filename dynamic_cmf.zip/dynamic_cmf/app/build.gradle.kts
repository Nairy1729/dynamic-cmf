plugins {
    alias(libs.plugins.island.android.application)
    alias(libs.plugins.island.hilt)
}

dependencies {
    implementation(project(":core:model"))
    implementation(project(":core:common"))
    implementation(project(":core:engine"))
    implementation(project(":motion:physics"))
    implementation(project(":motion:compose"))
    implementation(project(":platform:overlay"))
    implementation(project(":platform:notifications"))
    implementation(project(":platform:media"))
    implementation(project(":platform:telephony"))
    implementation(project(":platform:power"))
    implementation(project(":platform:bluetooth"))
    implementation(project(":platform:recording"))
    implementation(project(":platform:timers"))
    implementation(project(":platform:downloads"))
    implementation(project(":ui:theme"))
    implementation(project(":ui:island"))
    implementation(project(":ui:components"))
    implementation(project(":ui:settings"))
    implementation(project(":config"))
    implementation(project(":diagnostics"))
}
