package dev.island.dynamicisland

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import dev.island.dynamicisland.config.OverlayPreferences
import dev.island.dynamicisland.diagnostics.IslandLog
import dev.island.dynamicisland.diagnostics.LogTag
import dev.island.dynamicisland.platform.overlay.IslandOverlayService
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/**
 * Restarts the specialUse overlay service after boot when the user previously enabled it.
 */
public class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(
        context: Context,
        intent: Intent?,
    ) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED &&
            intent?.action != Intent.ACTION_LOCKED_BOOT_COMPLETED
        ) {
            return
        }
        val prefs = OverlayPreferences(context, debugOverlayDefault = false)
        val enabled = runBlocking { prefs.islandEnabled.first() }
        if (!enabled) {
            IslandLog.i(LogTag.APP, "BootCompleted: island disabled — skip")
            return
        }
        if (!Settings.canDrawOverlays(context)) {
            IslandLog.w(
                LogTag.APP,
                "BootCompleted: overlay permission revoked while powered off — skip start",
            )
            runBlocking { prefs.setIslandEnabled(false) }
            return
        }
        IslandLog.i(LogTag.APP, "BootCompleted: starting specialUse IslandOverlayService")
        IslandOverlayService.start(context)
    }
}
