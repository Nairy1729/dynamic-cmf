package dev.island.dynamicisland

import android.app.Application
import android.content.pm.ApplicationInfo
import android.hardware.display.DisplayManager
import android.os.Build
import android.view.Display
import dagger.hilt.android.HiltAndroidApp
import dev.island.dynamicisland.diagnostics.IslandLog
import dev.island.dynamicisland.diagnostics.LogTag
import java.util.Locale

@HiltAndroidApp
public class IslandApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        val debuggable = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        IslandLog.initialize(isDebuggable = debuggable)

        val diagnosticsLine = buildStartupDiagnostics()
        startupDiagnostics = diagnosticsLine
        IslandLog.i(LogTag.APP, diagnosticsLine)
    }

    private fun buildStartupDiagnostics(): String {
        val metrics = resources.displayMetrics
        val refreshRateHz = resolveRefreshRateHz()
        return buildString {
            append("Dynamic Island startup | ")
            append("version=").append(BuildConfig.VERSION_NAME)
            append(" (").append(BuildConfig.VERSION_CODE).append(") | ")
            append("sdk=").append(Build.VERSION.SDK_INT).append(" | ")
            append("device=")
                .append(Build.MANUFACTURER)
                .append(' ')
                .append(Build.MODEL)
                .append(" | ")
            append("display=").append(metrics.widthPixels).append('x').append(metrics.heightPixels)
            append("px density=").append(metrics.density)
            append(" dpi=").append(metrics.densityDpi)
            append(" refresh=").append(refreshRateHz).append("Hz")
        }
    }

    private fun resolveRefreshRateHz(): String {
        val display = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val rate = display?.refreshRate ?: 0f
        return String.format(Locale.US, "%.0f", rate)
    }

    public companion object {
        @Volatile
        public var startupDiagnostics: String = ""
            private set
    }
}
