package dev.island.dynamicisland

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import dev.island.dynamicisland.config.OverlayPreferences
import dev.island.dynamicisland.diagnostics.IslandLog
import dev.island.dynamicisland.diagnostics.LogTag
import dev.island.dynamicisland.platform.overlay.IslandOverlayService
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/**
 * Quick Settings tile — primary user-initiated start/stop path for the overlay service.
 */
public class IslandTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        val prefs = OverlayPreferences(this, debugOverlayDefault = BuildConfig.DEBUG)
        val enabled = runBlocking { prefs.islandEnabled.first() }
        if (enabled) {
            IslandLog.i(LogTag.APP, "QS tile: disable island")
            runBlocking { prefs.setIslandEnabled(false) }
            IslandOverlayService.stop(this)
        } else {
            IslandLog.i(LogTag.APP, "QS tile: enable island")
            if (!android.provider.Settings.canDrawOverlays(this)) {
                IslandLog.w(LogTag.APP, "QS tile: overlay permission missing")
                collapseToLauncher()
                return
            }
            runBlocking { prefs.setIslandEnabled(true) }
            IslandOverlayService.start(this)
        }
        refreshTile()
    }

    private fun collapseToLauncher() {
        val launch =
            packageManager.getLaunchIntentForPackage(packageName)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            } ?: return
        if (Build.VERSION.SDK_INT >= 34) {
            val pending =
                PendingIntent.getActivity(
                    this,
                    0,
                    launch,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
            startActivityAndCollapse(pending)
        } else {
            @Suppress("DEPRECATION")
            @android.annotation.SuppressLint("StartActivityAndCollapseDeprecated")
            startActivityAndCollapse(launch)
        }
    }

    private fun refreshTile() {
        val prefs = OverlayPreferences(this, debugOverlayDefault = BuildConfig.DEBUG)
        val enabled = runBlocking { prefs.islandEnabled.first() }
        qsTile?.apply {
            state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            label = "Island"
            contentDescription = "Toggle Dynamic Island overlay"
            updateTile()
        }
    }

    public companion object {
        public fun requestListening(context: Context) {
            val component = ComponentName(context, IslandTileService::class.java)
            requestListeningState(context, component)
        }
    }
}
