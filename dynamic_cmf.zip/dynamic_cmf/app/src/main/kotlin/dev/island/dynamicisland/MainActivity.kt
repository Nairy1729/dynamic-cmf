package dev.island.dynamicisland

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import dagger.hilt.android.AndroidEntryPoint
import dev.island.dynamicisland.config.OverlayPreferences
import dev.island.dynamicisland.platform.overlay.DisplayCutoutProbe
import dev.island.dynamicisland.platform.overlay.IslandOverlayService
import kotlinx.coroutines.launch
import java.util.Locale

@AndroidEntryPoint
public class MainActivity : ComponentActivity() {
    private lateinit var preferences: OverlayPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        preferences = OverlayPreferences(this, debugOverlayDefault = BuildConfig.DEBUG)
        setContent {
            MaterialTheme {
                OnboardingScreen(
                    preferences = preferences,
                    refreshKey = permissionEpoch,
                )
            }
        }
    }

    private var permissionEpoch by mutableStateOf(0)

    override fun onResume() {
        super.onResume()
        permissionEpoch++
    }
}

@Composable
@Suppress("ktlint:standard:function-naming")
private fun OnboardingScreen(
    preferences: OverlayPreferences,
    refreshKey: Int,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val islandEnabled by preferences.islandEnabled.collectAsState(initial = false)

    var overlayGranted by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var notifGranted by remember { mutableStateOf(notificationsGranted(context)) }
    var batteryExempt by remember { mutableStateOf(isIgnoringBatteryOptimizations(context)) }
    var cutoutRect by remember { mutableStateOf<Rect?>(null) }
    var diagnosticsText by remember { mutableStateOf("") }

    LaunchedEffect(refreshKey) {
        overlayGranted = Settings.canDrawOverlays(context)
        notifGranted = notificationsGranted(context)
        batteryExempt = isIgnoringBatteryOptimizations(context)
        diagnosticsText = buildDeviceReport(context) { cutoutRect = it }
    }

    val notifLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
            notifGranted = notificationsGranted(context)
        }

    Scaffold { padding ->
        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 20.dp)
                    .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Dynamic Island", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Enable the system overlay for the CMF punch-hole island.",
                style = MaterialTheme.typography.bodyMedium,
            )

            PermissionRow(
                title = "Display over other apps",
                explanation = "Required so the island can draw above the launcher and other apps.",
                granted = overlayGranted,
                actionLabel = if (overlayGranted) "Granted" else "Open Settings",
                onAction = {
                    val intent =
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}"),
                        )
                    context.startActivity(intent)
                },
            )

            PermissionRow(
                title = "Notifications",
                explanation = "Lets the island service show its ongoing status notification.",
                granted = notifGranted,
                actionLabel = if (notifGranted) "Granted" else "Allow",
                onAction = {
                    if (Build.VERSION.SDK_INT >= 33) {
                        notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                },
            )

            PermissionRow(
                title = "Battery optimisation exemption (optional)",
                explanation =
                    "Nothing OS aggressively kills background processes; exemption helps the " +
                        "island survive. You can skip this.",
                granted = batteryExempt,
                actionLabel = if (batteryExempt) "Exempted" else "Request",
                onAction = {
                    val intent =
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                    context.startActivity(intent)
                },
            )

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Enable Island", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (overlayGranted) {
                            "Starts the overlay foreground service."
                        } else {
                            "Grant overlay permission first."
                        },
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                Switch(
                    checked = islandEnabled && overlayGranted,
                    enabled = overlayGranted,
                    onCheckedChange = { enabled ->
                        scope.launch {
                            if (enabled) {
                                preferences.setIslandEnabled(true)
                                IslandOverlayService.start(context)
                            } else {
                                preferences.setIslandEnabled(false)
                                IslandOverlayService.stop(context)
                            }
                        }
                    },
                )
            }

            HorizontalDivider()
            Text("Diagnostics", style = MaterialTheme.typography.titleMedium)
            Text(
                diagnosticsText,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedButton(
                onClick = {
                    val clipboard = context.getSystemService(ClipboardManager::class.java)
                    clipboard.setPrimaryClip(ClipData.newPlainText("island_diagnostics", diagnosticsText))
                },
            ) {
                Text("Copy diagnostics")
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
@Suppress("ktlint:standard:function-naming")
private fun PermissionRow(
    title: String,
    explanation: String,
    granted: Boolean,
    actionLabel: String,
    onAction: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        Text(explanation, style = MaterialTheme.typography.bodySmall)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(if (granted) "Status: OK" else "Status: Needed")
            Button(onClick = onAction, enabled = !granted) {
                Text(actionLabel)
            }
        }
    }
}

private fun notificationsGranted(context: android.content.Context): Boolean {
    if (Build.VERSION.SDK_INT < 33) return true
    return ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.POST_NOTIFICATIONS,
    ) == PackageManager.PERMISSION_GRANTED
}

private fun isIgnoringBatteryOptimizations(context: android.content.Context): Boolean {
    val pm = context.getSystemService(PowerManager::class.java)
    return pm.isIgnoringBatteryOptimizations(context.packageName)
}

private fun buildDeviceReport(
    context: android.content.Context,
    onCutout: (Rect) -> Unit,
): String {
    val metrics = context.resources.displayMetrics
    val wm = context.getSystemService(WindowManager::class.java)
    val refresh =
        if (Build.VERSION.SDK_INT >= 30) {
            wm.defaultDisplay?.mode?.refreshRate ?: 0f
        } else {
            @Suppress("DEPRECATION")
            wm.defaultDisplay?.refreshRate ?: 0f
        }

    var cutoutText = "unavailable"
    val activity = context as? ComponentActivity
    val root = activity?.window?.decorView
    if (root != null) {
        val insets = ViewCompat.getRootWindowInsets(root)
        val statusTop =
            insets?.getInsets(WindowInsetsCompat.Type.statusBars())?.top
                ?: (metrics.density * 24).toInt()
        val platformInsets = root.rootWindowInsets
        val report =
            DisplayCutoutProbe().probeFromInsets(
                platformInsets,
                metrics.widthPixels,
                statusTop,
            )
        onCutout(report.boundingRectPx.toAndroidRect())
        cutoutText =
            "left=${report.boundingRectPx.left} top=${report.boundingRectPx.top} " +
            "right=${report.boundingRectPx.right} bottom=${report.boundingRectPx.bottom}" +
            if (report.usedFallback) " (fallback)" else ""
    }

    return buildString {
        appendLine("model=${Build.MANUFACTURER} ${Build.MODEL}")
        appendLine("sdk=${Build.VERSION.SDK_INT}")
        appendLine("display_px=${metrics.widthPixels}x${metrics.heightPixels}")
        appendLine("display_dp=${metrics.widthPixels / metrics.density}x${metrics.heightPixels / metrics.density}")
        appendLine("density=${metrics.density}")
        appendLine("densityDpi=${metrics.densityDpi}")
        appendLine("refreshRate=${String.format(Locale.US, "%.2f", refresh)}")
        append("DETECTED CUTOUT RECT: $cutoutText")
    }
}
