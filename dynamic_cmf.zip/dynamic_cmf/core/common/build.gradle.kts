plugins {
    alias(libs.plugins.island.jvm.library)
    `java-test-fixtures`
}

dependencies {
    testFixturesImplementation(kotlin("stdlib"))
}
