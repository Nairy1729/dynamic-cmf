package dev.island.dynamicisland.core.common

/**
 * Stable identity for an island activity. Defined in :core:common so both model and engine share it.
 */
@JvmInline
public value class ActivityId(
    public val value: String,
)
