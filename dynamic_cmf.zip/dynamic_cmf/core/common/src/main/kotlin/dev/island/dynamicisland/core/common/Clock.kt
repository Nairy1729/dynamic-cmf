package dev.island.dynamicisland.core.common

/**
 * Time source for hosts and tests. The pure [dev.island.dynamicisland.core.engine.ActivityEngine.reduce]
 * function never calls this — callers pass `now` explicitly.
 */
public interface Clock {
    public fun now(): Timestamp
}
