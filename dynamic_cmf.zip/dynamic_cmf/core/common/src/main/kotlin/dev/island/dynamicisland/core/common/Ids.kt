package dev.island.dynamicisland.core.common

/**
 * Deterministic activity id factory. Same inputs always yield the same [ActivityId].
 * Uses FNV-1a 64-bit over the joined parts plus a readable prefix from the first part.
 */
public object Ids {
    private const val FNV_OFFSET: Long = -0x340d631b7bdddcdbL
    private const val FNV_PRIME: Long = 0x100000001b3L

    public fun stable(vararg parts: String): ActivityId {
        require(parts.isNotEmpty()) { "stable() requires at least one part" }
        var hash = FNV_OFFSET
        for (part in parts) {
            for (index in part.indices) {
                hash = hash xor part[index].code.toLong()
                hash *= FNV_PRIME
            }
            hash = hash xor 0x1fL
            hash *= FNV_PRIME
        }
        val unsigned = hash.toULong().toString(16).padStart(16, '0')
        val prefix = sanitizePrefix(parts.first())
        return ActivityId("$prefix-$unsigned")
    }

    private fun sanitizePrefix(raw: String): String {
        val cleaned =
            buildString(capacity = raw.length.coerceAtMost(32)) {
                for (ch in raw) {
                    when {
                        ch.isLetterOrDigit() -> append(ch.lowercaseChar())
                        ch == '.' || ch == '_' || ch == '-' -> append('-')
                    }
                    if (length >= 24) break
                }
            }.trim('-')
        return cleaned.ifEmpty { "act" }
    }
}
