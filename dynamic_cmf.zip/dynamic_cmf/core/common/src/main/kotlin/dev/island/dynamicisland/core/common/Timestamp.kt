package dev.island.dynamicisland.core.common

import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds

/**
 * Discrete instant used by the activity engine. Never obtained from wall clocks inside core —
 * always injected via [Clock] or an explicit `now` argument.
 */
@JvmInline
public value class Timestamp(
    public val epochMillis: Long,
) : Comparable<Timestamp> {
    public operator fun plus(d: Duration): Timestamp = Timestamp(epochMillis + d.inWholeMilliseconds)

    public operator fun minus(d: Duration): Timestamp = Timestamp(epochMillis - d.inWholeMilliseconds)

    public operator fun minus(other: Timestamp): Duration = (epochMillis - other.epochMillis).milliseconds

    override fun compareTo(other: Timestamp): Int = epochMillis.compareTo(other.epochMillis)

    public companion object {
        public val UNSET: Timestamp = Timestamp(Long.MIN_VALUE)
    }
}
