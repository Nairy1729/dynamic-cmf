package dev.island.dynamicisland.core.common

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotEquals
import org.junit.jupiter.api.Test

class IdsTest {
    @Test
    fun `stable is deterministic`() {
        val a = Ids.stable("media", "com.spotify", "session-1")
        val b = Ids.stable("media", "com.spotify", "session-1")
        assertEquals(a, b)
    }

    @Test
    fun `stable differs when parts differ`() {
        val a = Ids.stable("media", "a")
        val b = Ids.stable("media", "b")
        assertNotEquals(a, b)
    }
}
