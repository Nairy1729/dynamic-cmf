package dev.island.dynamicisland.core.common

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import kotlin.time.Duration.Companion.seconds

class MutableTestClockTest {
    @Test
    fun `advanceBy and setTo control now`() {
        val clock = MutableTestClock(Timestamp(0))
        assertEquals(Timestamp(0), clock.now())
        clock.advanceBy(3.seconds)
        assertEquals(Timestamp(3_000), clock.now())
        clock.setTo(Timestamp(50))
        assertEquals(Timestamp(50), clock.now())
    }
}
