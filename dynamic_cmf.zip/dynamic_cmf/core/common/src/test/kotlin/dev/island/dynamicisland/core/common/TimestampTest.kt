package dev.island.dynamicisland.core.common

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds

class TimestampTest {
    @Test
    fun `plus and minus are inverses`() {
        val t0 = Timestamp(1_000L)
        val later = t0 + 2.5.seconds
        assertEquals(3_500L, later.epochMillis)
        assertEquals(2_500.milliseconds, later - t0)
        assertEquals(t0, later - 2.5.seconds)
    }

    @Test
    fun `compareTo orders by epoch`() {
        assertTrue(Timestamp(1) < Timestamp(2))
        assertEquals(0, Timestamp(5).compareTo(Timestamp(5)))
    }

    @Test
    fun `UNSET is distinct from zero`() {
        assertTrue(Timestamp.UNSET.epochMillis < 0L)
        assertTrue(Timestamp.UNSET < Timestamp(0))
    }
}
