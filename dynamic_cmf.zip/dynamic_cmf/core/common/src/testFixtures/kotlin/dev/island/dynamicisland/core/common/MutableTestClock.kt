package dev.island.dynamicisland.core.common

import kotlin.time.Duration

/**
 * Controllable [Clock] for unit tests. Lives in the `testFixtures` source set so
 * `:core:model` / `:core:engine` tests can depend on it without polluting main.
 */
public class MutableTestClock(
    private var current: Timestamp,
) : Clock {
    override fun now(): Timestamp = current

    public fun advanceBy(duration: Duration) {
        current = current + duration
    }

    public fun setTo(timestamp: Timestamp) {
        current = timestamp
    }
}
