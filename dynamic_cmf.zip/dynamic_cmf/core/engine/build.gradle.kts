plugins {

    alias(libs.plugins.island.jvm.library)

    alias(libs.plugins.kover)
}

dependencies {

    api(project(":core:model"))

    implementation(project(":core:common"))

    implementation(libs.kotlinx.coroutines.core)

    testImplementation(testFixtures(project(":core:common")))
}

kover {

    reports {

        filters {

            excludes {

                classes("dev.island.dynamicisland.core.engine.ActivityEngineHost")
            }
        }

        verify {

            rule {

                minBound(85)
            }
        }
    }
}
