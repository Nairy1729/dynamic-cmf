package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.common.ActivityId
import dev.island.dynamicisland.core.common.Timestamp
import dev.island.dynamicisland.core.model.ActivityDraft
import dev.island.dynamicisland.core.model.ActivityIntent
import dev.island.dynamicisland.core.model.ActivityLifecycle
import dev.island.dynamicisland.core.model.EngineEffect
import dev.island.dynamicisland.core.model.EngineEvent
import dev.island.dynamicisland.core.model.GestureIntent
import dev.island.dynamicisland.core.model.IslandActivity
import dev.island.dynamicisland.core.model.IslandPresentation
import dev.island.dynamicisland.core.model.IslandUiState
import dev.island.dynamicisland.core.model.Persistence
import dev.island.dynamicisland.core.model.PresentationReason
import dev.island.dynamicisland.core.model.PriorityBand
import dev.island.dynamicisland.core.model.RetireReason

/**
 * Pure, deterministic activity engine. Same `(state, event, now)` always yields the same result.
 * Side effects are declared as [EngineEffect] only — never performed here.
 */
public object ActivityEngine {
    private val policy: RelevancePolicy = DefaultRelevancePolicy()

    public fun reduce(
        state: EngineState,
        event: EngineEvent,
        now: Timestamp,
    ): EngineResult {
        val cleared = state.copy(watchdogForceCompleted = emptyList(), lastTransitionRejected = false)
        return when (event) {
            is EngineEvent.Intent -> handleIntent(cleared, event.intent, now)
            is EngineEvent.Gesture -> handleGesture(cleared, event.gesture, now)
            is EngineEvent.TimeAdvanced -> handleTimeAdvanced(cleared, event.now)
            is EngineEvent.ExitAnimationComplete -> handleExitComplete(cleared, event.id, now)
            is EngineEvent.ConfigChanged -> handleConfigChanged(cleared, event.config, now)
            is EngineEvent.ContextChanged -> handleContextChanged(cleared, event.context, now)
        }
    }

    private fun handleIntent(
        state: EngineState,
        intent: ActivityIntent,
        now: Timestamp,
    ): EngineResult =
        when (intent) {
            is ActivityIntent.Upsert -> upsert(state, intent.activity, now)
            is ActivityIntent.Retire -> retireIds(state, setOf(intent.id), intent.reason, now)
            is ActivityIntent.RetireBySource -> {
                val ids =
                    state.activities
                        .filter { it.value.source == intent.source }
                        .keys
                retireIds(state, ids, intent.reason, now)
            }
            is ActivityIntent.RetireByType -> {
                val ids =
                    state.activities
                        .filter { it.value.type == intent.type }
                        .keys
                retireIds(state, ids, intent.reason, now)
            }
            ActivityIntent.ClearAll -> retireIds(state, state.activities.keys, RetireReason.CLEARED, now)
        }

    private fun upsert(
        state: EngineState,
        draft: ActivityDraft,
        now: Timestamp,
    ): EngineResult {
        val admission = policy.admit(draft, state, now)
        return when (admission) {
            is Admission.Rejected -> {
                val effects = listOf(EngineEffect.Rejected(draft.source, admission.reason))
                EngineResult(state, presentationOf(state, PresentationReason.NONE), effects)
            }
            is Admission.Coalesce -> applyCoalesce(state, draft, admission.intoId, now)
            Admission.Admitted -> applyAdmit(state, draft, now)
        }
    }

    private fun applyAdmit(
        state: EngineState,
        draft: ActivityDraft,
        now: Timestamp,
    ): EngineResult {
        var activities = state.activities
        var restoreStack = state.restoreStack
        // Evict lowest DORMANT if at capacity.
        val liveCount = activities.count { it.value.lifecycle != ActivityLifecycle.RETIRED }
        if (liveCount >= state.config.maxQueuedActivities) {
            val evictable =
                activities.values
                    .filter { it.lifecycle == ActivityLifecycle.DORMANT }
                    .minWithOrNull(compareBy({ it.resolvedPriority }, { it.id.value }))
            if (evictable != null) {
                activities = activities - evictable.id
                restoreStack = restoreStack.filter { it != evictable.id }
            }
        }
        val resolved = PriorityResolver.resolve(draft, state.config, state.context)
        val expiresAt = computeExpiresAt(draft, state.config, now)
        val created =
            IslandActivity(
                id = draft.id,
                type = draft.type,
                source = draft.source,
                basePriority = draft.basePriority,
                resolvedPriority = resolved,
                lifecycle = ActivityLifecycle.ACTIVE,
                persistence = draft.persistence,
                createdAt = now,
                updatedAt = now,
                expiresAt = expiresAt,
                compact = draft.compact,
                expanded = draft.expanded,
                interaction = draft.interaction,
                actions = draft.actions,
                dedupeKey = draft.dedupeKey,
                revision = 0L,
                aggregateCount = 1,
            )
        activities = activities + (created.id to created)
        var rateWindows = state.rateWindows
        val pkg = draft.source.packageName
        if (draft.persistence == Persistence.TRANSIENT && pkg != null) {
            val windowStart = now - state.config.rateLimitWindow
            val updated =
                (rateWindows[pkg].orEmpty() + now).filter { it >= windowStart }
            rateWindows = rateWindows + (pkg to updated)
        }
        val working =
            state.copy(
                activities = activities,
                restoreStack = restoreStack,
                rateWindows = rateWindows,
            )
        return finalizeAfterMutation(
            previous = state,
            working = working,
            now = now,
            reasonHint = PresentationReason.ENTER,
            bypassThrash = false,
            extraEffects = emptyList(),
            retiredTransientPrimary = false,
        )
    }

    private fun applyCoalesce(
        state: EngineState,
        draft: ActivityDraft,
        intoId: ActivityId,
        now: Timestamp,
    ): EngineResult {
        val existing = state.activities[intoId] ?: return applyAdmit(state, draft, now)
        val resolved = PriorityResolver.resolve(draft, state.config, state.context)
        val expiresAt = computeExpiresAt(draft, state.config, now)
        val rateLimitedCoalesce =
            existing.source.packageName != null &&
                existing.source.packageName == draft.source.packageName &&
                existing.dedupeKey != draft.dedupeKey
        val updated =
            existing.copy(
                type = draft.type,
                source = draft.source,
                basePriority = draft.basePriority,
                resolvedPriority = resolved,
                persistence = draft.persistence,
                updatedAt = now,
                expiresAt = expiresAt,
                compact = draft.compact,
                expanded = draft.expanded,
                interaction = draft.interaction,
                actions = draft.actions,
                dedupeKey = draft.dedupeKey,
                revision = existing.revision + 1,
                aggregateCount = if (rateLimitedCoalesce) existing.aggregateCount + 1 else existing.aggregateCount,
                lifecycle =
                    if (existing.lifecycle == ActivityLifecycle.DORMANT) {
                        ActivityLifecycle.DORMANT
                    } else {
                        ActivityLifecycle.ACTIVE
                    },
            )
        val working = state.copy(activities = state.activities + (intoId to updated))
        val samePrimary = state.primaryId == intoId
        return finalizeAfterMutation(
            previous = state,
            working = working,
            now = now,
            reasonHint = if (samePrimary) PresentationReason.CONTENT_UPDATE else PresentationReason.ENTER,
            bypassThrash = false,
            extraEffects = emptyList(),
            retiredTransientPrimary = false,
        )
    }

    private fun retireIds(
        state: EngineState,
        ids: Set<ActivityId>,
        reason: RetireReason,
        now: Timestamp,
    ): EngineResult {
        if (ids.isEmpty()) {
            return EngineResult(state, presentationOf(state, PresentationReason.NONE), emptyList())
        }
        var activities = state.activities
        var restoreStack = state.restoreStack
        var retiringDeadlines = state.retiringDeadlines
        val effects = mutableListOf<EngineEffect>()
        var retiredTransientPrimary = false
        for (id in ids) {
            val activity = activities[id] ?: continue
            if (activity.lifecycle == ActivityLifecycle.RETIRING ||
                activity.lifecycle == ActivityLifecycle.RETIRED
            ) {
                continue
            }
            if (id == state.primaryId && activity.persistence == Persistence.TRANSIENT) {
                retiredTransientPrimary = true
            }
            activities =
                activities + (
                    id to activity.copy(lifecycle = ActivityLifecycle.RETIRING, updatedAt = now)
                )
            restoreStack = restoreStack.filter { it != id }
            retiringDeadlines = retiringDeadlines + (id to (now + state.config.exitAnimationTimeout))
            effects += EngineEffect.RequestExitAnimation(id)
            if (reason == RetireReason.USER_DISMISSED) {
                effects += EngineEffect.NotifySourceDismissed(activity.source)
            }
        }
        effects += EngineEffect.ScheduleWake(now + state.config.exitAnimationTimeout)
        val working =
            state.copy(
                activities = activities,
                restoreStack = restoreStack,
                retiringDeadlines = retiringDeadlines,
            )
        return finalizeAfterMutation(
            previous = state,
            working = working,
            now = now,
            reasonHint = PresentationReason.EXIT,
            bypassThrash = false,
            extraEffects = effects,
            retiredTransientPrimary = retiredTransientPrimary,
        )
    }

    private fun handleExitComplete(
        state: EngineState,
        id: ActivityId,
        now: Timestamp,
    ): EngineResult {
        if (id !in state.activities) {
            return EngineResult(state, presentationOf(state, PresentationReason.NONE), emptyList())
        }
        val working =
            state.copy(
                activities = state.activities - id,
                retiringDeadlines = state.retiringDeadlines - id,
                restoreStack = state.restoreStack.filter { it != id },
                primaryId = if (state.primaryId == id) null else state.primaryId,
                secondaryId = if (state.secondaryId == id) null else state.secondaryId,
                pendingPrimaryId = if (state.pendingPrimaryId == id) null else state.pendingPrimaryId,
            )
        return finalizeAfterMutation(
            previous = state,
            working = working,
            now = now,
            reasonHint = PresentationReason.EXIT,
            bypassThrash = false,
            extraEffects = emptyList(),
            retiredTransientPrimary = state.primaryId == id,
        )
    }

    private fun handleTimeAdvanced(
        state: EngineState,
        now: Timestamp,
    ): EngineResult {
        var activities = state.activities
        var retiringDeadlines = state.retiringDeadlines
        val forceCompleted = mutableListOf<ActivityId>()
        // Watchdog: force-complete RETIRING past deadline.
        for ((id, deadline) in state.retiringDeadlines) {
            if (now >= deadline) {
                activities = activities - id
                retiringDeadlines = retiringDeadlines - id
                forceCompleted += id
            }
        }
        // TTL expiry.
        val expired =
            activities.values
                .filter { activity ->
                    val expiresAt = activity.expiresAt
                    expiresAt != null &&
                        now >= expiresAt &&
                        activity.lifecycle != ActivityLifecycle.RETIRING &&
                        activity.lifecycle != ActivityLifecycle.RETIRED
                }.map { it.id }
                .toSet()
        var working =
            state.copy(
                activities = activities,
                retiringDeadlines = retiringDeadlines,
                restoreStack = state.restoreStack.filter { it in activities },
                watchdogForceCompleted = forceCompleted,
                primaryId = state.primaryId?.takeIf { it in activities },
                secondaryId = state.secondaryId?.takeIf { it in activities },
                pendingPrimaryId = state.pendingPrimaryId?.takeIf { it in activities },
            )
        val retiredTransientPrimary = forceCompleted.any { it == state.primaryId }
        if (expired.isNotEmpty()) {
            val afterExpire = retireIds(working, expired, RetireReason.EXPIRED, now)
            return afterExpire.copy(
                state = afterExpire.state.copy(watchdogForceCompleted = forceCompleted),
            )
        }
        // Thrash guard release: re-evaluate from scratch past the window.
        val thrashRelease =
            state.pendingPrimaryId != null &&
                state.lastPrimarySwapAt != Timestamp.UNSET &&
                now >= state.lastPrimarySwapAt + state.config.thrashGuardWindow
        // Auto-collapse.
        val shouldCollapse =
            !working.touchHeld &&
                working.uiState != IslandUiState.INTERACTIVE &&
                working.autoCollapseAt != null &&
                now >= working.autoCollapseAt
        var reasonHint = PresentationReason.NONE
        if (shouldCollapse) {
            val collapsed =
                IslandStateMachine.transition(working.uiState, IslandUiState.COMPACT)
                    ?: working.uiState
            working = working.copy(uiState = collapsed, autoCollapseAt = null)
            reasonHint = PresentationReason.COLLAPSE_AUTO
        }
        return finalizeAfterMutation(
            previous = state,
            working = working.copy(pendingPrimaryId = if (thrashRelease) null else working.pendingPrimaryId),
            now = now,
            reasonHint = reasonHint,
            bypassThrash = thrashRelease,
            extraEffects = emptyList(),
            retiredTransientPrimary = retiredTransientPrimary,
        )
    }

    private fun handleConfigChanged(
        state: EngineState,
        config: dev.island.dynamicisland.core.model.EngineConfig,
        now: Timestamp,
    ): EngineResult {
        val rebased =
            state.activities.mapValues { (_, activity) ->
                val draft = activity.toDraft()
                activity.copy(
                    resolvedPriority = PriorityResolver.resolve(draft, config, state.context),
                )
            }
        val working = state.copy(config = config, activities = rebased)
        return finalizeAfterMutation(
            previous = state,
            working = working,
            now = now,
            reasonHint = PresentationReason.RECONFIGURE,
            bypassThrash = true,
            extraEffects = emptyList(),
            retiredTransientPrimary = false,
        )
    }

    private fun handleContextChanged(
        state: EngineState,
        context: dev.island.dynamicisland.core.model.SystemContext,
        now: Timestamp,
    ): EngineResult {
        val rebased =
            state.activities.mapValues { (_, activity) ->
                activity.copy(
                    resolvedPriority =
                        PriorityResolver.resolve(activity.toDraft(), state.config, context),
                )
            }
        val working = state.copy(context = context, activities = rebased)
        return finalizeAfterMutation(
            previous = state,
            working = working,
            now = now,
            reasonHint = PresentationReason.RECONFIGURE,
            bypassThrash = true,
            extraEffects = emptyList(),
            retiredTransientPrimary = false,
        )
    }

    private fun handleGesture(
        state: EngineState,
        gesture: GestureIntent,
        now: Timestamp,
    ): EngineResult {
        val primary = state.primaryId?.let { state.activities[it] }
        return when (gesture) {
            GestureIntent.Tap -> {
                if (primary == null) {
                    return unchanged(state)
                }
                if (primary.interaction.expandable) {
                    applyUi(state, IslandUiState.EXPANDED, PresentationReason.EXPAND_USER, now)
                } else {
                    val action = primary.actions.firstOrNull { it.isPrimary } ?: primary.actions.firstOrNull()
                    if (action != null) {
                        EngineResult(
                            state,
                            presentationOf(state, PresentationReason.NONE),
                            listOf(EngineEffect.InvokeAction(primary.id, action.id)),
                        )
                    } else {
                        unchanged(state)
                    }
                }
            }
            GestureIntent.LongPress -> unchanged(state)
            GestureIntent.OutsideTap -> {
                if (state.uiState == IslandUiState.EXPANDED || state.uiState == IslandUiState.INTERACTIVE) {
                    applyUi(state, IslandUiState.COMPACT, PresentationReason.COLLAPSE_USER, now)
                } else {
                    unchanged(state)
                }
            }
            GestureIntent.SwipeDismiss -> {
                if (primary?.interaction?.swipeDismissible == true) {
                    retireIds(state, setOf(primary.id), RetireReason.USER_DISMISSED, now)
                } else {
                    unchanged(state)
                }
            }
            GestureIntent.SwipeNext -> rotatePrimary(state, now, forward = true)
            GestureIntent.SwipePrevious -> rotatePrimary(state, now, forward = false)
            is GestureIntent.ExpandRequest ->
                applyUi(state, IslandUiState.EXPANDED, PresentationReason.EXPAND_USER, now)
            is GestureIntent.CollapseRequest ->
                applyUi(state, IslandUiState.COMPACT, PresentationReason.COLLAPSE_USER, now)
            GestureIntent.EnterInteractive -> {
                if (state.uiState != IslandUiState.EXPANDED) {
                    return rejectedTransition(state)
                }
                val can =
                    primary?.actions?.any { it.requiresInteractiveState } == true
                if (!can) return rejectedTransition(state)
                applyUi(state, IslandUiState.INTERACTIVE, PresentationReason.EXPAND_USER, now)
            }
            GestureIntent.ExitInteractive ->
                applyUi(state, IslandUiState.EXPANDED, PresentationReason.COLLAPSE_USER, now)
            is GestureIntent.TouchHold -> {
                if (gesture.isHeld) {
                    val working = state.copy(touchHeld = true, autoCollapseAt = null)
                    finish(working, PresentationReason.NONE, emptyList(), state)
                } else {
                    val delay =
                        if (primary?.persistence == Persistence.TRANSIENT) {
                            state.config.transientExpandedDuration
                        } else {
                            state.config.ongoingAutoCollapseDelay
                        }
                    val restarted =
                        if (state.uiState == IslandUiState.EXPANDED) {
                            now + delay
                        } else {
                            null
                        }
                    val working = state.copy(touchHeld = false, autoCollapseAt = restarted)
                    finish(working, PresentationReason.NONE, emptyList(), state)
                }
            }
            is GestureIntent.ActionInvoked -> {
                EngineResult(
                    state,
                    presentationOf(state, PresentationReason.NONE),
                    listOf(EngineEffect.InvokeAction(gesture.activityId, gesture.actionId)),
                )
            }
        }
    }

    private fun applyUi(
        state: EngineState,
        target: IslandUiState,
        reason: PresentationReason,
        now: Timestamp,
    ): EngineResult {
        val next = IslandStateMachine.transition(state.uiState, target)
        if (next == null) return rejectedTransition(state)
        var autoCollapseAt = state.autoCollapseAt
        val primary = state.primaryId?.let { state.activities[it] }
        if (next == IslandUiState.EXPANDED && !state.touchHeld) {
            val delay =
                if (primary?.persistence == Persistence.TRANSIENT) {
                    state.config.transientExpandedDuration
                } else {
                    state.config.ongoingAutoCollapseDelay
                }
            autoCollapseAt = now + delay
        }
        if (next == IslandUiState.INTERACTIVE || next == IslandUiState.COMPACT || next == IslandUiState.COLLAPSED) {
            if (next != IslandUiState.EXPANDED) {
                autoCollapseAt = if (next == IslandUiState.INTERACTIVE) null else null
            }
        }
        if (next == IslandUiState.COMPACT || next == IslandUiState.COLLAPSED || next == IslandUiState.MINIMAL) {
            autoCollapseAt = null
        }
        if (next == IslandUiState.INTERACTIVE) {
            autoCollapseAt = null
        }
        val working = state.copy(uiState = next, autoCollapseAt = autoCollapseAt)
        return finish(working, reason, emptyList(), state)
    }

    private fun rotatePrimary(
        state: EngineState,
        now: Timestamp,
        forward: Boolean,
    ): EngineResult {
        val ordered = rotationCandidates(state)
        if (ordered.size < 2) return unchanged(state)
        val currentIndex = ordered.indexOf(state.primaryId).coerceAtLeast(0)
        val nextIndex =
            if (forward) {
                (currentIndex + 1) % ordered.size
            } else {
                (currentIndex - 1 + ordered.size) % ordered.size
            }
        val nextId = ordered[nextIndex]
        var activities = state.activities
        // Promote DORMANT selection target to ACTIVE for presentation.
        val target = activities[nextId]
        if (target != null && target.lifecycle == ActivityLifecycle.DORMANT) {
            activities = activities + (nextId to target.copy(lifecycle = ActivityLifecycle.ACTIVE))
        }
        val working =
            state.copy(
                activities = activities,
                primaryId = nextId,
                pendingPrimaryId = null,
                lastPrimarySwapAt = now,
            )
        return finalizeAfterMutation(
            previous = state,
            working = working,
            now = now,
            reasonHint = PresentationReason.PRIMARY_SWAP,
            bypassThrash = true,
            extraEffects = emptyList(),
            retiredTransientPrimary = false,
            primaryAlreadySet = true,
        )
    }

    private fun rotationCandidates(state: EngineState): List<ActivityId> =
        state.activities.values
            .filter {
                it.lifecycle == ActivityLifecycle.ACTIVE || it.lifecycle == ActivityLifecycle.DORMANT
            }.sortedWith(primaryComparator())
            .map { it.id }

    private fun finalizeAfterMutation(
        previous: EngineState,
        working: EngineState,
        now: Timestamp,
        reasonHint: PresentationReason,
        bypassThrash: Boolean,
        extraEffects: List<EngineEffect>,
        retiredTransientPrimary: Boolean,
        primaryAlreadySet: Boolean = false,
    ): EngineResult {
        var activities = working.activities
        var restoreStack = working.restoreStack
        var reason = reasonHint
        var primaryId = working.primaryId
        var pendingPrimaryId = working.pendingPrimaryId
        var lastPrimarySwapAt = working.lastPrimarySwapAt
        var uiState = working.uiState
        var autoCollapseAt = working.autoCollapseAt
        val effects = extraEffects.toMutableList()
        // Restore / transient-exit primary swaps must never be deferred by the thrash guard.
        val allowSwap = bypassThrash || retiredTransientPrimary

        if (retiredTransientPrimary) {
            val restored = popRestore(activities, restoreStack)
            activities = restored.activities
            restoreStack = restored.restoreStack
            if (restored.promotedId != null) {
                reason = PresentationReason.RESTORE
            }
        }

        if (!primaryAlreadySet) {
            val computed = selectPrimaryId(activities)
            if (computed != primaryId) {
                val computedActivity = computed?.let { activities[it] }
                val thrashBlocked =
                    !allowSwap &&
                        primaryId != null &&
                        computed != null &&
                        lastPrimarySwapAt != Timestamp.UNSET &&
                        now - lastPrimarySwapAt < working.config.thrashGuardWindow &&
                        computedActivity != null &&
                        computedActivity.bandIsProtectedFromThrash().not()
                if (thrashBlocked) {
                    pendingPrimaryId = computed
                    effects +=
                        EngineEffect.ScheduleWake(
                            lastPrimarySwapAt + working.config.thrashGuardWindow,
                        )
                } else {
                    val oldPrimary = primaryId?.let { activities[it] }
                    val newPrimary = computedActivity
                    if (
                        oldPrimary != null &&
                        newPrimary != null &&
                        newPrimary.persistence == Persistence.TRANSIENT &&
                        (
                            oldPrimary.persistence == Persistence.ONGOING ||
                                oldPrimary.persistence == Persistence.STICKY
                        )
                    ) {
                        activities =
                            activities + (
                                oldPrimary.id to
                                    oldPrimary.copy(lifecycle = ActivityLifecycle.DORMANT)
                            )
                        restoreStack =
                            pushRestore(
                                restoreStack,
                                oldPrimary.id,
                                working.config.restoreStackDepth,
                            )
                        reason = PresentationReason.PREEMPT
                    } else if (
                        computed != null &&
                        primaryId != null &&
                        reason != PresentationReason.PREEMPT &&
                        reason != PresentationReason.RESTORE &&
                        reason != PresentationReason.ENTER &&
                        reason != PresentationReason.EXIT
                    ) {
                        reason = PresentationReason.PRIMARY_SWAP
                    }
                    if (primaryId != computed) {
                        lastPrimarySwapAt = now
                    }
                    primaryId = computed
                    pendingPrimaryId = null
                }
            } else if (allowSwap && pendingPrimaryId != null) {
                // Released thrash: apply recomputed winner (already equals primary or updated).
                pendingPrimaryId = null
            }
        }

        // Ensure primary is ACTIVE.
        if (primaryId != null) {
            val p = activities[primaryId]
            if (p != null && p.lifecycle == ActivityLifecycle.DORMANT) {
                activities = activities + (primaryId to p.copy(lifecycle = ActivityLifecycle.ACTIVE))
            }
        }

        val secondaryId = selectSecondaryId(activities, primaryId)

        if (activities.isEmpty() || primaryId == null) {
            uiState = IslandUiState.DORMANT
            autoCollapseAt = null
            primaryId = null
        } else if (uiState == IslandUiState.DORMANT) {
            val primary = activities[primaryId]
            uiState =
                if (primary?.interaction?.autoExpandOnEnter == true &&
                    primary.persistence == Persistence.TRANSIENT
                ) {
                    autoCollapseAt = now + working.config.transientExpandedDuration
                    if (reason == PresentationReason.ENTER || reason == PresentationReason.PREEMPT) {
                        reason = if (reason == PresentationReason.PREEMPT) reason else PresentationReason.EXPAND_AUTO
                    }
                    IslandUiState.EXPANDED
                } else {
                    IslandUiState.COMPACT
                }
        }

        // CONTENT_UPDATE only when primary identity unchanged.
        if (reason == PresentationReason.CONTENT_UPDATE && previous.primaryId != primaryId) {
            reason = PresentationReason.PRIMARY_SWAP
        }
        if (previous.primaryId != primaryId &&
            reason == PresentationReason.NONE &&
            primaryId != null
        ) {
            reason = PresentationReason.PRIMARY_SWAP
        }

        val nextState =
            working.copy(
                activities = activities,
                primaryId = primaryId,
                secondaryId = secondaryId,
                restoreStack = restoreStack,
                uiState = uiState,
                lastPrimarySwapAt = lastPrimarySwapAt,
                pendingPrimaryId = pendingPrimaryId,
                autoCollapseAt = autoCollapseAt,
            )
        return finish(nextState, reason, effects, previous)
    }

    private fun finish(
        nextState: EngineState,
        reason: PresentationReason,
        extraEffects: List<EngineEffect>,
        previous: EngineState,
    ): EngineResult {
        val previousPresentation = presentationOf(previous, PresentationReason.NONE)
        val (presentation, wakeEffects) = PresentationPlanner.plan(nextState, previousPresentation, reason)
        val stateWithSeq = nextState.copy(seq = presentation.seq)
        return EngineResult(stateWithSeq, presentation, extraEffects + wakeEffects)
    }

    private fun presentationOf(
        state: EngineState,
        reason: PresentationReason,
    ): IslandPresentation = PresentationPlanner.plan(state, IslandPresentation.Empty, reason).first.copy(seq = state.seq)

    private fun unchanged(state: EngineState): EngineResult =
        EngineResult(state, presentationOf(state, PresentationReason.NONE), emptyList())

    private fun rejectedTransition(state: EngineState): EngineResult =
        EngineResult(
            state.copy(lastTransitionRejected = true),
            presentationOf(state, PresentationReason.NONE),
            emptyList(),
        )

    private fun computeExpiresAt(
        draft: ActivityDraft,
        config: dev.island.dynamicisland.core.model.EngineConfig,
        now: Timestamp,
    ): Timestamp? {
        if (draft.expiresAt != null) return draft.expiresAt
        return when (draft.persistence) {
            Persistence.TRANSIENT ->
                now + config.transientExpandedDuration + config.transientCompactDuration
            Persistence.ONGOING, Persistence.STICKY -> null
        }
    }

    private fun selectPrimaryId(activities: Map<ActivityId, IslandActivity>): ActivityId? =
        activities.values
            .filter { it.lifecycle == ActivityLifecycle.ACTIVE }
            .minWithOrNull(primaryComparator())
            ?.id

    private fun selectSecondaryId(
        activities: Map<ActivityId, IslandActivity>,
        primaryId: ActivityId?,
    ): ActivityId? {
        val primary = primaryId?.let { activities[it] } ?: return null
        return activities.values
            .filter { activity ->
                activity.id != primaryId &&
                    (
                        activity.lifecycle == ActivityLifecycle.ACTIVE ||
                            activity.lifecycle == ActivityLifecycle.DORMANT
                    ) &&
                    activity.type != primary.type &&
                    activity.compact.leading != null
            }.minWithOrNull(primaryComparator())
            ?.id
    }

    private fun primaryComparator(): Comparator<IslandActivity> =
        Comparator { a, b ->
            val byPriority = b.resolvedPriority.compareTo(a.resolvedPriority)
            if (byPriority != 0) return@Comparator byPriority
            val aCrit =
                a.resolvedPriority.band == PriorityBand.CRITICAL ||
                    a.resolvedPriority.band == PriorityBand.ONGOING_CRITICAL
            val bCrit =
                b.resolvedPriority.band == PriorityBand.CRITICAL ||
                    b.resolvedPriority.band == PriorityBand.ONGOING_CRITICAL
            if (aCrit && bCrit) {
                val byRecency = b.createdAt.compareTo(a.createdAt)
                if (byRecency != 0) return@Comparator byRecency
            }
            val persist = persistenceRank(b.persistence) - persistenceRank(a.persistence)
            if (persist != 0) return@Comparator persist
            val byOldest = a.createdAt.compareTo(b.createdAt)
            if (byOldest != 0) return@Comparator byOldest
            a.id.value.compareTo(b.id.value)
        }

    private fun persistenceRank(persistence: Persistence): Int =
        when (persistence) {
            Persistence.STICKY -> 2
            Persistence.ONGOING -> 2
            Persistence.TRANSIENT -> 1
        }

    private fun IslandActivity.bandIsProtectedFromThrash(): Boolean {
        val band = resolvedPriority.band
        return band == PriorityBand.CRITICAL || band == PriorityBand.ONGOING_CRITICAL
    }

    private fun pushRestore(
        stack: List<ActivityId>,
        id: ActivityId,
        depth: Int,
    ): List<ActivityId> {
        val without = stack.filter { it != id }
        return (listOf(id) + without).take(depth)
    }

    private data class RestorePop(
        val activities: Map<ActivityId, IslandActivity>,
        val restoreStack: List<ActivityId>,
        val promotedId: ActivityId?,
    )

    private fun popRestore(
        activities: Map<ActivityId, IslandActivity>,
        restoreStack: List<ActivityId>,
    ): RestorePop {
        var stack = restoreStack
        var map = activities
        while (stack.isNotEmpty()) {
            val id = stack.first()
            stack = stack.drop(1)
            val activity = map[id] ?: continue
            if (activity.lifecycle == ActivityLifecycle.RETIRING ||
                activity.lifecycle == ActivityLifecycle.RETIRED
            ) {
                continue
            }
            map = map + (id to activity.copy(lifecycle = ActivityLifecycle.ACTIVE))
            return RestorePop(map, stack, id)
        }
        return RestorePop(map, stack, null)
    }

    private fun IslandActivity.toDraft(): ActivityDraft =
        ActivityDraft(
            id = id,
            type = type,
            source = source,
            basePriority = basePriority,
            persistence = persistence,
            expiresAt = expiresAt,
            compact = compact,
            expanded = expanded,
            interaction = interaction,
            actions = actions,
            dedupeKey = dedupeKey,
        )
}
