package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.common.Timestamp
import dev.island.dynamicisland.core.model.EngineConfig
import dev.island.dynamicisland.core.model.EngineEffect
import dev.island.dynamicisland.core.model.EngineEvent
import dev.island.dynamicisland.core.model.IslandPresentation
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Thin stateful host over [ActivityEngine.reduce].
 *
 * Effects are exposed as a hot [Flow] (not a callback) so multiple collectors — overlay,
 * haptics, wake scheduler — can subscribe independently and tests can use Turbine.
 */
public class ActivityEngineHost(
    initialConfig: EngineConfig,
) {
    private val stateFlow = MutableStateFlow(EngineState.initial(initialConfig))
    private val presentationFlow = MutableStateFlow(IslandPresentation.Empty)
    private val effectsFlow =
        MutableSharedFlow<EngineEffect>(
            extraBufferCapacity = 64,
            replay = 0,
        )

    public val presentation: StateFlow<IslandPresentation> = presentationFlow.asStateFlow()
    public val effects: Flow<EngineEffect> = effectsFlow.asSharedFlow()

    public fun dispatch(
        event: EngineEvent,
        now: Timestamp,
    ) {
        val result = ActivityEngine.reduce(stateFlow.value, event, now)
        stateFlow.value = result.state
        presentationFlow.value = result.presentation
        for (effect in result.effects) {
            effectsFlow.tryEmit(effect)
        }
    }

    public fun snapshot(): EngineState = stateFlow.value
}
