package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.common.ActivityId
import dev.island.dynamicisland.core.model.RejectReason

public sealed interface Admission {
    public data object Admitted : Admission

    public data class Rejected(
        public val reason: RejectReason,
    ) : Admission

    public data class Coalesce(
        public val intoId: ActivityId,
    ) : Admission
}
