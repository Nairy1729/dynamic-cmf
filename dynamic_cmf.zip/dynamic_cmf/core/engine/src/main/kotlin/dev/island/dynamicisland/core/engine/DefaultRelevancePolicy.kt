package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.common.Timestamp
import dev.island.dynamicisland.core.model.ActivityDraft
import dev.island.dynamicisland.core.model.ActivityLifecycle
import dev.island.dynamicisland.core.model.Persistence
import dev.island.dynamicisland.core.model.PriorityBand
import dev.island.dynamicisland.core.model.RejectReason

public class DefaultRelevancePolicy : RelevancePolicy {
    override fun admit(
        draft: ActivityDraft,
        state: EngineState,
        now: Timestamp,
    ): Admission {
        val config = state.config
        if (draft.type in config.disabledTypes) {
            return Admission.Rejected(RejectReason.TYPE_DISABLED)
        }
        val pkg = draft.source.packageName
        if (pkg != null && pkg in config.blockedPackages) {
            return Admission.Rejected(RejectReason.BLOCKED_PACKAGE)
        }

        val resolvedProbe = PriorityResolver.resolve(draft, config, state.context)
        val bypassRemaining =
            (pkg != null && pkg in config.alwaysAllowPackages) ||
                resolvedProbe.band == PriorityBand.CRITICAL ||
                resolvedProbe.band == PriorityBand.ONGOING_CRITICAL

        if (!bypassRemaining && draft.persistence == Persistence.TRANSIENT) {
            if (state.context.inCall && config.suppressTransientsInCall) {
                return Admission.Rejected(RejectReason.QUIET_CONTEXT)
            }
            if (!state.context.screenOn && config.suppressTransientsWhileScreenOff) {
                return Admission.Rejected(RejectReason.QUIET_CONTEXT)
            }
            if (state.context.cameraActive && config.suppressTransientsWhileCameraActive) {
                return Admission.Rejected(RejectReason.QUIET_CONTEXT)
            }
        }

        val existing =
            state.activities.values.firstOrNull { activity ->
                activity.dedupeKey == draft.dedupeKey &&
                    activity.lifecycle != ActivityLifecycle.RETIRED &&
                    activity.lifecycle != ActivityLifecycle.RETIRING
            }
        if (existing != null) {
            return Admission.Coalesce(existing.id)
        }

        if (!bypassRemaining && draft.persistence == Persistence.TRANSIENT && pkg != null) {
            val windowStart = now - config.rateLimitWindow
            val recent =
                state.rateWindows[pkg]
                    .orEmpty()
                    .filter { it >= windowStart }
            if (recent.size >= config.rateLimitMaxPerPackage) {
                val coalesceTarget =
                    state.activities.values
                        .filter { activity ->
                            activity.source.packageName == pkg &&
                                (
                                    activity.lifecycle == ActivityLifecycle.ACTIVE ||
                                        activity.lifecycle == ActivityLifecycle.DORMANT
                                )
                        }.maxByOrNull { it.updatedAt }
                return if (coalesceTarget != null) {
                    Admission.Coalesce(coalesceTarget.id)
                } else {
                    Admission.Rejected(RejectReason.RATE_LIMITED)
                }
            }
        }

        val liveCount =
            state.activities.count { (_, activity) ->
                activity.lifecycle != ActivityLifecycle.RETIRED
            }
        if (liveCount >= config.maxQueuedActivities) {
            val evictable =
                state.activities.values
                    .filter { it.lifecycle == ActivityLifecycle.DORMANT }
                    .minByOrNull { it.resolvedPriority }
            if (evictable == null && resolvedProbe.band != PriorityBand.CRITICAL) {
                return Admission.Rejected(RejectReason.LOW_IMPORTANCE)
            }
        }

        return Admission.Admitted
    }
}
