package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.common.ActivityId
import dev.island.dynamicisland.core.common.Timestamp
import dev.island.dynamicisland.core.model.EngineConfig
import dev.island.dynamicisland.core.model.EngineEffect
import dev.island.dynamicisland.core.model.IslandActivity
import dev.island.dynamicisland.core.model.IslandPresentation
import dev.island.dynamicisland.core.model.IslandUiState
import dev.island.dynamicisland.core.model.SystemContext

public data class EngineState(
    public val activities: Map<ActivityId, IslandActivity>,
    public val primaryId: ActivityId?,
    public val secondaryId: ActivityId?,
    public val restoreStack: List<ActivityId>,
    public val uiState: IslandUiState,
    public val lastPrimarySwapAt: Timestamp,
    public val pendingPrimaryId: ActivityId?,
    public val retiringDeadlines: Map<ActivityId, Timestamp>,
    public val rateWindows: Map<String, List<Timestamp>>,
    public val touchHeld: Boolean,
    public val autoCollapseAt: Timestamp?,
    public val context: SystemContext,
    public val config: EngineConfig,
    public val seq: Long,
    /** Ids force-removed by the exit-animation watchdog on the last TimeAdvanced tick. */
    public val watchdogForceCompleted: List<ActivityId> = emptyList(),
    /** True when the last gesture requested an illegal UI transition (state unchanged). */
    public val lastTransitionRejected: Boolean = false,
) {
    public companion object {
        public fun initial(config: EngineConfig): EngineState =
            EngineState(
                activities = emptyMap(),
                primaryId = null,
                secondaryId = null,
                restoreStack = emptyList(),
                uiState = IslandUiState.DORMANT,
                lastPrimarySwapAt = Timestamp.UNSET,
                pendingPrimaryId = null,
                retiringDeadlines = emptyMap(),
                rateWindows = emptyMap(),
                touchHeld = false,
                autoCollapseAt = null,
                context = SystemContext.Default,
                config = config,
                seq = 0L,
                watchdogForceCompleted = emptyList(),
                lastTransitionRejected = false,
            )
    }
}

public data class EngineResult(
    public val state: EngineState,
    public val presentation: IslandPresentation,
    public val effects: List<EngineEffect>,
)
