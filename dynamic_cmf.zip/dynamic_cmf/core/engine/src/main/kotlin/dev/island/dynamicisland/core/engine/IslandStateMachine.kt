package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.model.IslandUiState

/**
 * Legal [IslandUiState] transitions. Illegal transitions return null (reject without throw).
 */
public object IslandStateMachine {
    public fun transition(
        from: IslandUiState,
        to: IslandUiState,
    ): IslandUiState? {
        if (from == to) return to
        return if (isLegal(from, to)) to else null
    }

    public fun isLegal(
        from: IslandUiState,
        to: IslandUiState,
    ): Boolean {
        if (from == to) return true
        if (to == IslandUiState.DISMISSED) return true
        if (to == IslandUiState.DORMANT) return true
        if (from == IslandUiState.DISMISSED && to == IslandUiState.DORMANT) return true
        return when (from) {
            IslandUiState.DORMANT ->
                to == IslandUiState.COLLAPSED || to == IslandUiState.COMPACT
            IslandUiState.COLLAPSED ->
                to == IslandUiState.COMPACT || to == IslandUiState.MINIMAL
            IslandUiState.MINIMAL ->
                to == IslandUiState.COMPACT || to == IslandUiState.COLLAPSED
            IslandUiState.COMPACT ->
                to == IslandUiState.COLLAPSED ||
                    to == IslandUiState.MINIMAL ||
                    to == IslandUiState.EXPANDED
            IslandUiState.EXPANDED ->
                to == IslandUiState.COMPACT || to == IslandUiState.INTERACTIVE
            IslandUiState.INTERACTIVE ->
                // R11 OutsideTap: INTERACTIVE -> COMPACT; R10 also allows return to EXPANDED.
                to == IslandUiState.EXPANDED || to == IslandUiState.COMPACT
            IslandUiState.DISMISSED ->
                to == IslandUiState.DORMANT
        }
    }
}
