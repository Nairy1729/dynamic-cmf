package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.model.EngineEffect
import dev.island.dynamicisland.core.model.IslandPresentation
import dev.island.dynamicisland.core.model.IslandUiState
import dev.island.dynamicisland.core.model.PresentationReason
import dev.island.dynamicisland.core.model.PresentedActivity

/**
 * Builds [IslandPresentation] and wake-related effects from a committed [EngineState].
 */
public object PresentationPlanner {
    public fun plan(
        state: EngineState,
        previous: IslandPresentation,
        reason: PresentationReason,
    ): Pair<IslandPresentation, List<EngineEffect>> {
        val primary =
            state.primaryId?.let { id ->
                state.activities[id]?.let { PresentedActivity(it, state.seq + 1) }
            }
        val secondary =
            state.secondaryId?.let { id ->
                state.activities[id]?.let { PresentedActivity(it, state.seq + 1) }
            }
        val queuedCount =
            state.activities.count { (_, activity) ->
                activity.id != state.primaryId && activity.id != state.secondaryId
            }
        val interactionEnabled =
            state.uiState == IslandUiState.EXPANDED ||
                state.uiState == IslandUiState.INTERACTIVE ||
                state.uiState == IslandUiState.COMPACT
        val presentation =
            IslandPresentation(
                uiState = state.uiState,
                primary = primary,
                secondary = secondary,
                queuedCount = queuedCount,
                reason = reason,
                autoCollapseAt = state.autoCollapseAt,
                interactionEnabled = interactionEnabled,
                seq = state.seq + 1,
            )
        val effects = wakeEffects(previous.autoCollapseAt, state.autoCollapseAt)
        return presentation to effects
    }

    private fun wakeEffects(
        previousAutoCollapse: dev.island.dynamicisland.core.common.Timestamp?,
        nextAutoCollapse: dev.island.dynamicisland.core.common.Timestamp?,
    ): List<EngineEffect> =
        when {
            previousAutoCollapse == nextAutoCollapse -> emptyList()
            nextAutoCollapse == null -> listOf(EngineEffect.CancelWake)
            else -> listOf(EngineEffect.ScheduleWake(nextAutoCollapse))
        }
}
