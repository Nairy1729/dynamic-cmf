package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.model.ActivityDraft
import dev.island.dynamicisland.core.model.EngineConfig
import dev.island.dynamicisland.core.model.Persistence
import dev.island.dynamicisland.core.model.Priority
import dev.island.dynamicisland.core.model.PriorityBand
import dev.island.dynamicisland.core.model.SystemContext

/**
 * Resolves [IslandActivity.resolvedPriority] from draft + config + context.
 *
 * Context boost hook: when a foreground-equivalent package signal becomes available,
 * add +40 here. Always 0 until that platform signal exists.
 */
public object PriorityResolver {
    public fun resolve(
        draft: ActivityDraft,
        config: EngineConfig,
        context: SystemContext,
    ): Priority {
        val userDelta = config.userPriorityDeltas[draft.type]?.coerceIn(-150, 150) ?: 0
        val contextBoost = contextBoost(draft, context)
        val dndPenalty =
            if (draft.persistence == Persistence.TRANSIENT && context.doNotDisturb) {
                -100
            } else {
                0
            }
        val raw = draft.basePriority.value + userDelta + contextBoost + dndPenalty
        val clamped = raw.coerceIn(100, 1000)
        return enforceCriticalBoundary(base = draft.basePriority, resolved = clamped)
    }

    /**
     * Foreground-equivalent boost. Documented hook — always returns 0 until the host
     * can supply a matching signal on [SystemContext] (future task).
     */
    public fun contextBoost(
        draft: ActivityDraft,
        context: SystemContext,
    ): Int {
        // Hook reserved for foreground-equivalent package matching. [context] unused until then.
        @Suppress("UNUSED_PARAMETER")
        val unused = context

        @Suppress("UNUSED_PARAMETER")
        val unusedDraft = draft
        return 0
    }

    private fun enforceCriticalBoundary(
        base: Priority,
        resolved: Int,
    ): Priority {
        if (base.value >= 900) {
            return Priority(resolved)
        }
        // Must not cross into CRITICAL (>=900) unless base was already there.
        return Priority(resolved.coerceAtMost(PriorityBand.ONGOING_CRITICAL.range.last))
    }
}
