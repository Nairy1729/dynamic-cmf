package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.common.Timestamp
import dev.island.dynamicisland.core.model.ActivityDraft

public interface RelevancePolicy {
    public fun admit(
        draft: ActivityDraft,
        state: EngineState,
        now: Timestamp,
    ): Admission
}
