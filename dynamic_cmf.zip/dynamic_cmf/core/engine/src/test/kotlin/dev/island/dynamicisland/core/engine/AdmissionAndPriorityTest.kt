package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.common.Ids
import dev.island.dynamicisland.core.common.Timestamp
import dev.island.dynamicisland.core.model.ActivityType
import dev.island.dynamicisland.core.model.EngineConfig
import dev.island.dynamicisland.core.model.Priority
import dev.island.dynamicisland.core.model.PriorityBand
import dev.island.dynamicisland.core.model.RejectReason
import dev.island.dynamicisland.core.model.SystemContext
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds

class AdmissionAndPriorityTest {
    private val t0 = Timestamp(1_000_000)

    @Test
    fun `admission rejects disabled type`() {
        val config = EngineConfig(disabledTypes = setOf(ActivityType.NOTIFICATION))
        engine(config).at(t0).upsert(notification("com.app")).expectRejected(RejectReason.TYPE_DISABLED)
    }

    @Test
    fun `admission rejects blocked package`() {
        val config = EngineConfig(blockedPackages = setOf("com.spam"))
        engine(config).at(t0).upsert(notification("com.spam")).expectRejected(RejectReason.BLOCKED_PACKAGE)
    }

    @Test
    fun `admission alwaysAllow bypasses quiet context`() {
        val config = EngineConfig(alwaysAllowPackages = setOf("com.important"))
        engine(config)
            .at(t0)
            .context(SystemContext.Default.copy(inCall = true))
            .upsert(notification("com.important"))
            .expectPrimary(ActivityType.NOTIFICATION)
    }

    @Test
    fun `admission critical bypasses quiet context`() {
        engine()
            .at(t0)
            .context(SystemContext.Default.copy(inCall = true))
            .upsert(call())
            .expectPrimary(ActivityType.CALL)
    }

    @Test
    fun `admission quiet context in-call rejects transient`() {
        engine()
            .at(t0)
            .context(SystemContext.Default.copy(inCall = true))
            .upsert(notification("com.wa"))
            .expectRejected(RejectReason.QUIET_CONTEXT)
    }

    @Test
    fun `admission quiet context screen-off rejects transient`() {
        engine()
            .at(t0)
            .context(SystemContext.Default.copy(screenOn = false))
            .upsert(notification("com.wa"))
            .expectRejected(RejectReason.QUIET_CONTEXT)
    }

    @Test
    fun `admission quiet context camera rejects transient`() {
        engine()
            .at(t0)
            .context(SystemContext.Default.copy(cameraActive = true))
            .upsert(notification("com.wa"))
            .expectRejected(RejectReason.QUIET_CONTEXT)
    }

    @Test
    fun `admission dedupe coalesces same dedupeKey`() {
        val n = notification("com.wa", key = "same")
        val second =
            notification("com.wa", key = "same").copy(
                compact = n.compact.copy(accessibilityLabel = "updated"),
            )
        val scenario =
            engine()
                .at(t0)
                .upsert(n)
                .at(t0 + 1.seconds)
                .upsert(second)
        assertEquals(1, scenario.snapshot.activities.size)
        assertEquals(1L, scenario.activity(n.id).revision)
    }

    @Test
    fun `admission rate limit coalesces into most recent same package`() {
        val config = EngineConfig(rateLimitMaxPerPackage = 2)
        val a = notification("com.wa", key = "a")
        val b = notification("com.wa", key = "b")
        val c = notification("com.wa", key = "c")
        val scenario =
            engine(config)
                .at(t0)
                .upsert(a)
                .at(t0 + 10.milliseconds)
                .upsert(b)
                .at(t0 + 20.milliseconds)
                .upsert(c)
        assertEquals(2, scenario.snapshot.activities.size)
        assertTrue(scenario.activity(b.id).aggregateCount >= 2)
        scenario.expectAbsent(c.id)
    }

    @Test
    fun `admission rate limit rejects when no coalesce target`() {
        val config = EngineConfig(rateLimitMaxPerPackage = 1)
        val a = notification("com.wa", key = "a")
        engine(config)
            .at(t0)
            .upsert(a)
            .retire(a.id)
            .exitComplete(a.id)
            .at(t0 + 10.milliseconds)
            .upsert(notification("com.wa", key = "b"))
            .expectRejected(RejectReason.RATE_LIMITED)
    }

    @Test
    fun `admission eviction at max capacity removes lowest dormant`() {
        val config = EngineConfig(maxQueuedActivities = 2, restoreStackDepth = 4)
        val media = media()
        val low = custom("low", Priority(300))
        val high = notification("com.wa")
        val scenario =
            engine(config)
                .at(t0)
                .upsert(media)
                .at(t0 + 1.seconds)
                .upsert(high)
                .expectReason(dev.island.dynamicisland.core.model.PresentationReason.PREEMPT)
                .expectLifecycle(media.id, dev.island.dynamicisland.core.model.ActivityLifecycle.DORMANT)
                .at(t0 + 2.seconds)
                .upsert(low)
        // At capacity 2 with media dormant + notif active; admitting low may evict media.
        assertTrue(scenario.snapshot.activities.size <= 2 || scenario.snapshot.activities.containsKey(low.id))
    }

    @Test
    fun `admission critical admitted when full with no evictable`() {
        val config = EngineConfig(maxQueuedActivities = 1)
        engine(config)
            .at(t0)
            .upsert(media())
            .at(t0 + 1.seconds)
            .upsert(call())
            .expectPrimary(ActivityType.CALL)
    }

    @Test
    fun `priority user delta applied`() {
        val config = EngineConfig(userPriorityDeltas = mapOf(ActivityType.MEDIA to 50))
        val draft = media()
        val scenario = engine(config).at(t0).upsert(draft)
        assertEquals(470, scenario.activity(draft.id).resolvedPriority.value)
    }

    @Test
    fun `priority user delta clamped at plus 150`() {
        val config = EngineConfig(userPriorityDeltas = mapOf(ActivityType.MEDIA to 999))
        val draft = media()
        val scenario = engine(config).at(t0).upsert(draft)
        assertEquals(570, scenario.activity(draft.id).resolvedPriority.value)
    }

    @Test
    fun `priority user delta clamped at minus 150`() {
        val config = EngineConfig(userPriorityDeltas = mapOf(ActivityType.MEDIA to -999))
        val draft = media()
        val scenario = engine(config).at(t0).upsert(draft)
        assertEquals(270, scenario.activity(draft.id).resolvedPriority.value)
    }

    @Test
    fun `priority DND penalty on transients`() {
        val scenario =
            engine()
                .at(t0)
                .context(SystemContext.Default.copy(doNotDisturb = true))
                .upsert(notification("com.wa"))
        assertEquals(500, scenario.activity(Ids.stable("notif", "com.wa", "n1")).resolvedPriority.value)
    }

    @Test
    fun `priority clamp prevents crossing into CRITICAL`() {
        val draft = download(priority = Priority(850))
        val config = EngineConfig(userPriorityDeltas = mapOf(ActivityType.DOWNLOAD to 150))
        val scenario = engine(config).at(t0).upsert(draft)
        assertEquals(PriorityBand.ONGOING_CRITICAL.range.last, scenario.activity(draft.id).resolvedPriority.value)
        assertTrue(scenario.activity(draft.id).resolvedPriority.value < 900)
    }

    @Test
    fun `call phase priorities incoming active ended`() {
        assertEquals(
            950,
            PriorityResolver
                .resolve(call(EngineConfig.CallBases.INCOMING), EngineConfig(), SystemContext.Default)
                .value,
        )
        assertEquals(
            820,
            PriorityResolver
                .resolve(call(EngineConfig.CallBases.ACTIVE_OR_HELD), EngineConfig(), SystemContext.Default)
                .value,
        )
        assertEquals(
            520,
            PriorityResolver
                .resolve(call(EngineConfig.CallBases.ENDED), EngineConfig(), SystemContext.Default)
                .value,
        )
    }

    @Test
    fun `ongoing never expires without explicit expiresAt`() {
        val draft = media()
        val scenario = engine().at(t0).upsert(draft)
        assertEquals(null, scenario.activity(draft.id).expiresAt)
        scenario.advanceTo(t0 + 1_000.seconds).expectPrimary(ActivityType.MEDIA)
    }

    @Test
    fun `explicit expiresAt honoured for ongoing`() {
        val expires = t0 + 5.seconds
        val draft = media().copy(expiresAt = expires)
        engine()
            .at(t0)
            .upsert(draft)
            .advanceTo(expires)
            .expectLifecycle(draft.id, dev.island.dynamicisland.core.model.ActivityLifecycle.RETIRING)
    }
}
