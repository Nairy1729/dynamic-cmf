package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.common.ActivityId
import dev.island.dynamicisland.core.common.Timestamp
import dev.island.dynamicisland.core.model.ActivityDraft
import dev.island.dynamicisland.core.model.ActivityIntent
import dev.island.dynamicisland.core.model.ActivityLifecycle
import dev.island.dynamicisland.core.model.ActivityType
import dev.island.dynamicisland.core.model.EngineConfig
import dev.island.dynamicisland.core.model.EngineEffect
import dev.island.dynamicisland.core.model.EngineEvent
import dev.island.dynamicisland.core.model.GestureIntent
import dev.island.dynamicisland.core.model.IslandPresentation
import dev.island.dynamicisland.core.model.IslandUiState
import dev.island.dynamicisland.core.model.PresentationReason
import dev.island.dynamicisland.core.model.RejectReason
import dev.island.dynamicisland.core.model.RetireReason
import dev.island.dynamicisland.core.model.SystemContext
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import kotlin.time.Duration

/**
 * Fluent scenario DSL for deterministic engine tests.
 *
 * Usage:
 * ```
 * engine.at(t0).upsert(media()).expectPrimary(ActivityType.MEDIA)
 * ```
 */
internal class EngineScenario(
    config: EngineConfig = EngineConfig(),
) {
    private var state: EngineState = EngineState.initial(config)
    private var now: Timestamp = Timestamp(0)
    private var last: EngineResult =
        EngineResult(state, IslandPresentation.Empty, emptyList())
    private val presentations = mutableListOf<IslandPresentation>()

    val snapshot: EngineState get() = state
    val result: EngineResult get() = last
    val emittedPresentations: List<IslandPresentation> get() = presentations.toList()
    val effects: List<EngineEffect> get() = last.effects

    fun at(timestamp: Timestamp): EngineScenario {
        now = timestamp
        return this
    }

    fun advanceTo(timestamp: Timestamp): EngineScenario {
        now = timestamp
        return dispatch(EngineEvent.TimeAdvanced(timestamp))
    }

    fun advanceBy(duration: Duration): EngineScenario = advanceTo(now + duration)

    fun upsert(draft: ActivityDraft): EngineScenario = dispatch(EngineEvent.Intent(ActivityIntent.Upsert(draft)))

    fun retire(
        id: ActivityId,
        reason: RetireReason = RetireReason.SOURCE_ENDED,
    ): EngineScenario = dispatch(EngineEvent.Intent(ActivityIntent.Retire(id, reason)))

    fun retirePrimary(reason: RetireReason = RetireReason.SOURCE_ENDED): EngineScenario {
        val id = state.primaryId ?: error("no primary to retire")
        return retire(id, reason)
    }

    fun clearAll(): EngineScenario = dispatch(EngineEvent.Intent(ActivityIntent.ClearAll))

    fun gesture(gesture: GestureIntent): EngineScenario = dispatch(EngineEvent.Gesture(gesture))

    fun exitComplete(id: ActivityId): EngineScenario = dispatch(EngineEvent.ExitAnimationComplete(id))

    fun config(config: EngineConfig): EngineScenario = dispatch(EngineEvent.ConfigChanged(config))

    fun context(context: SystemContext): EngineScenario = dispatch(EngineEvent.ContextChanged(context))

    fun dispatch(
        event: EngineEvent,
        at: Timestamp = now,
    ): EngineScenario {
        now = at
        last = ActivityEngine.reduce(state, event, at)
        state = last.state
        presentations += last.presentation
        return this
    }

    fun expectPrimary(type: ActivityType?): EngineScenario {
        val primary = state.primaryId?.let { state.activities[it] }
        assertEquals(type, primary?.type, "primary type")
        return this
    }

    fun expectPrimaryId(id: ActivityId?): EngineScenario {
        assertEquals(id, state.primaryId, "primaryId")
        return this
    }

    fun expectReason(reason: PresentationReason): EngineScenario {
        assertEquals(reason, last.presentation.reason, "presentation reason")
        return this
    }

    fun expectUi(ui: IslandUiState): EngineScenario {
        assertEquals(ui, state.uiState, "uiState")
        return this
    }

    fun expectRejected(reason: RejectReason): EngineScenario {
        val rejected = last.effects.filterIsInstance<EngineEffect.Rejected>()
        assertTrue(rejected.any { it.reason == reason }, "expected Rejected($reason), got ${last.effects}")
        return this
    }

    fun expectEffect(predicate: (EngineEffect) -> Boolean): EngineScenario {
        assertTrue(last.effects.any(predicate), "effects=${last.effects}")
        return this
    }

    fun expectNoEffect(predicate: (EngineEffect) -> Boolean): EngineScenario {
        assertFalse(last.effects.any(predicate), "unexpected effect in ${last.effects}")
        return this
    }

    fun expectPending(id: ActivityId?): EngineScenario {
        assertEquals(id, state.pendingPrimaryId, "pendingPrimaryId")
        return this
    }

    fun expectRestoreStack(ids: List<ActivityId> = emptyList()): EngineScenario {
        assertEquals(ids, state.restoreStack, "restoreStack")
        return this
    }

    fun expectLifecycle(
        id: ActivityId,
        lifecycle: ActivityLifecycle,
    ): EngineScenario {
        assertEquals(lifecycle, state.activities.getValue(id).lifecycle, "lifecycle of $id")
        return this
    }

    fun expectAbsent(id: ActivityId): EngineScenario {
        assertNull(state.activities[id], "activity $id should be absent")
        return this
    }

    fun expectPresent(id: ActivityId): EngineScenario {
        assertNotNull(state.activities[id], "activity $id should be present")
        return this
    }

    fun expectAggregate(
        id: ActivityId,
        count: Int,
    ): EngineScenario {
        assertEquals(count, state.activities.getValue(id).aggregateCount)
        return this
    }

    fun expectAutoCollapse(at: Timestamp?): EngineScenario {
        assertEquals(at, state.autoCollapseAt, "autoCollapseAt")
        return this
    }

    fun expectTransitionRejected(): EngineScenario {
        assertTrue(state.lastTransitionRejected, "expected lastTransitionRejected")
        return this
    }

    fun expectWatchdog(ids: List<ActivityId>): EngineScenario {
        assertEquals(ids, state.watchdogForceCompleted)
        return this
    }

    fun expectActivityCount(count: Int): EngineScenario {
        assertEquals(count, state.activities.size, "activity count")
        return this
    }

    fun primaryId(): ActivityId = state.primaryId ?: error("no primary")

    fun activity(id: ActivityId) = state.activities.getValue(id)
}

internal fun engine(config: EngineConfig = EngineConfig()): EngineScenario = EngineScenario(config)
