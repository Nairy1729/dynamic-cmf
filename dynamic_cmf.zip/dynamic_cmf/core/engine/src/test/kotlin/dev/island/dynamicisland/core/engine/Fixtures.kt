package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.common.ActivityId
import dev.island.dynamicisland.core.common.Ids
import dev.island.dynamicisland.core.common.Timestamp
import dev.island.dynamicisland.core.model.ActionKind
import dev.island.dynamicisland.core.model.ActivityAction
import dev.island.dynamicisland.core.model.ActivityDraft
import dev.island.dynamicisland.core.model.ActivitySource
import dev.island.dynamicisland.core.model.ActivityType
import dev.island.dynamicisland.core.model.CompactContent
import dev.island.dynamicisland.core.model.EngineConfig
import dev.island.dynamicisland.core.model.ExpandedContent
import dev.island.dynamicisland.core.model.Glyph
import dev.island.dynamicisland.core.model.GlyphId
import dev.island.dynamicisland.core.model.InteractionModel
import dev.island.dynamicisland.core.model.Persistence
import dev.island.dynamicisland.core.model.Priority

internal fun baseConfig(block: EngineConfig.() -> EngineConfig = { this }): EngineConfig = EngineConfig().block()

internal fun draft(
    type: ActivityType,
    id: ActivityId = Ids.stable(type.name.lowercase(), "default"),
    source: ActivitySource = ActivitySource.Internal(type.name.lowercase()),
    basePriority: Priority = EngineConfig.DEFAULT_BASE_PRIORITIES.getValue(type),
    persistence: Persistence =
        when (type) {
            ActivityType.MEDIA, ActivityType.NAVIGATION, ActivityType.TIMER,
            ActivityType.STOPWATCH, ActivityType.RECORDING_SCREEN, ActivityType.RECORDING_VOICE,
            -> Persistence.ONGOING
            ActivityType.CALL, ActivityType.ALARM -> Persistence.STICKY
            else -> Persistence.TRANSIENT
        },
    expiresAt: Timestamp? = null,
    dedupeKey: String = id.value,
    expandable: Boolean = true,
    autoExpandOnEnter: Boolean = persistence == Persistence.TRANSIENT,
    swipeDismissible: Boolean = persistence == Persistence.TRANSIENT,
    leading: Glyph? = glyphFor(type),
    actions: List<ActivityAction> = emptyList(),
    title: String = type.name,
): ActivityDraft {
    val expanded =
        if (expandable) {
            ExpandedContent(
                title = title,
                subtitle = null,
                body = null,
                media = null,
                detail = null,
                accessibilityLabel = title,
            )
        } else {
            null
        }
    return ActivityDraft(
        id = id,
        type = type,
        source = source,
        basePriority = basePriority,
        persistence = persistence,
        expiresAt = expiresAt,
        compact =
            CompactContent(
                leading = leading,
                trailing = null,
                accessibilityLabel = title,
            ),
        expanded = expanded,
        interaction =
            InteractionModel(
                tappable = true,
                expandable = expandable,
                swipeDismissible = swipeDismissible,
                longPressable = false,
                autoExpandOnEnter = autoExpandOnEnter && expandable,
            ),
        actions = actions,
        dedupeKey = dedupeKey,
    )
}

internal fun media(
    id: String = "media-1",
    pkg: String = "com.spotify",
): ActivityDraft =
    draft(
        type = ActivityType.MEDIA,
        id = Ids.stable("media", id),
        source = ActivitySource.MediaSession(pkg, id),
        persistence = Persistence.ONGOING,
        autoExpandOnEnter = false,
        swipeDismissible = false,
    )

internal fun notification(
    pkg: String,
    key: String = "n1",
    priority: Priority = Priority(600),
    id: ActivityId = Ids.stable("notif", pkg, key),
): ActivityDraft =
    draft(
        type = ActivityType.NOTIFICATION,
        id = id,
        source = ActivitySource.Notification(pkg, "default", key),
        basePriority = priority,
        persistence = Persistence.TRANSIENT,
        autoExpandOnEnter = true,
        swipeDismissible = true,
    )

internal fun call(
    phasePriority: Priority = EngineConfig.CallBases.INCOMING,
    id: String = "call-1",
): ActivityDraft =
    draft(
        type = ActivityType.CALL,
        id = Ids.stable("call", id),
        source = ActivitySource.Telecom,
        basePriority = phasePriority,
        persistence = Persistence.STICKY,
        autoExpandOnEnter = true,
        swipeDismissible = false,
    )

internal fun download(
    id: String = "dl-1",
    priority: Priority = Priority(360),
): ActivityDraft =
    draft(
        type = ActivityType.DOWNLOAD,
        id = Ids.stable("download", id),
        source = ActivitySource.Internal("download-$id"),
        basePriority = priority,
        persistence = Persistence.ONGOING,
        autoExpandOnEnter = false,
    )

internal fun custom(
    id: String,
    priority: Priority = Priority(300),
    persistence: Persistence = Persistence.ONGOING,
): ActivityDraft =
    draft(
        type = ActivityType.CUSTOM,
        id = Ids.stable("custom", id),
        source = ActivitySource.Internal(id),
        basePriority = priority,
        persistence = persistence,
        autoExpandOnEnter = false,
        swipeDismissible = false,
    )

internal fun primaryOpenAction(): ActivityAction =
    ActivityAction(
        id = "open",
        label = "Open",
        glyph = GlyphId.APP,
        kind = ActionKind.OPEN,
        isPrimary = true,
        requiresInteractiveState = false,
    )

internal fun replyAction(): ActivityAction =
    ActivityAction(
        id = "reply",
        label = "Reply",
        glyph = GlyphId.MESSAGE,
        kind = ActionKind.REPLY,
        isPrimary = true,
        requiresInteractiveState = true,
    )

private fun glyphFor(type: ActivityType): Glyph =
    Glyph(
        when (type) {
            ActivityType.CALL -> GlyphId.PHONE
            ActivityType.ALARM -> GlyphId.ALARM
            ActivityType.TIMER -> GlyphId.TIMER
            ActivityType.STOPWATCH -> GlyphId.STOPWATCH
            ActivityType.MEDIA -> GlyphId.MUSIC
            ActivityType.NAVIGATION -> GlyphId.NAVIGATION
            ActivityType.RECORDING_SCREEN -> GlyphId.SCREEN_RECORD
            ActivityType.RECORDING_VOICE -> GlyphId.MIC
            ActivityType.CHARGING -> GlyphId.BOLT
            ActivityType.BATTERY -> GlyphId.BATTERY
            ActivityType.BLUETOOTH -> GlyphId.BLUETOOTH
            ActivityType.DOWNLOAD -> GlyphId.DOWNLOAD
            ActivityType.NOTIFICATION -> GlyphId.BELL
            ActivityType.CUSTOM -> GlyphId.APP
        },
    )
