package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.common.Timestamp
import dev.island.dynamicisland.core.model.ActivityType
import dev.island.dynamicisland.core.model.EngineConfig
import dev.island.dynamicisland.core.model.EngineEffect
import dev.island.dynamicisland.core.model.EngineEvent
import dev.island.dynamicisland.core.model.GestureIntent
import dev.island.dynamicisland.core.model.IslandUiState
import dev.island.dynamicisland.core.model.PresentationReason
import dev.island.dynamicisland.core.model.Priority
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds

class GestureAutoCollapsePurityTest {
    private val t0 = Timestamp(3_000_000)

    @Test
    fun `auto-collapse transient auto-expand then collapse`() {
        val config = EngineConfig(transientExpandedDuration = 2.seconds)
        val n = notification("com.wa")
        engine(config)
            .at(t0)
            .upsert(n)
            .expectUi(IslandUiState.EXPANDED)
            .expectReason(PresentationReason.EXPAND_AUTO)
            .expectAutoCollapse(t0 + 2.seconds)
            .advanceTo(t0 + 2.seconds)
            .expectUi(IslandUiState.COMPACT)
            .expectReason(PresentationReason.COLLAPSE_AUTO)
    }

    @Test
    fun `auto-collapse touch hold cancels`() {
        val config = EngineConfig(transientExpandedDuration = 2.seconds)
        engine(config)
            .at(t0)
            .upsert(notification("com.wa"))
            .gesture(GestureIntent.TouchHold(true))
            .expectAutoCollapse(null)
            .expectEffect { it is EngineEffect.CancelWake }
    }

    @Test
    fun `auto-collapse touch release restarts`() {
        val config = EngineConfig(transientExpandedDuration = 2.seconds)
        engine(config)
            .at(t0)
            .upsert(notification("com.wa"))
            .gesture(GestureIntent.TouchHold(true))
            .at(t0 + 500.milliseconds)
            .gesture(GestureIntent.TouchHold(false))
            .expectAutoCollapse(t0 + 500.milliseconds + 2.seconds)
            .expectEffect { it is EngineEffect.ScheduleWake }
    }

    @Test
    fun `auto-collapse INTERACTIVE suspends it`() {
        val n =
            notification("com.wa").copy(
                actions = listOf(replyAction()),
            )
        engine()
            .at(t0)
            .upsert(n)
            .expectUi(IslandUiState.EXPANDED)
            .gesture(GestureIntent.EnterInteractive)
            .expectUi(IslandUiState.INTERACTIVE)
            .expectAutoCollapse(null)
    }

    @Test
    fun `gesture tap expands when expandable`() {
        engine()
            .at(t0)
            .upsert(media())
            .expectUi(IslandUiState.COMPACT)
            .gesture(GestureIntent.Tap)
            .expectUi(IslandUiState.EXPANDED)
            .expectReason(PresentationReason.EXPAND_USER)
    }

    @Test
    fun `gesture tap invokes default action when not expandable`() {
        val draft =
            notification("com.wa").copy(
                expanded = null,
                interaction =
                    notification("com.wa").interaction.copy(
                        expandable = false,
                        autoExpandOnEnter = false,
                    ),
                actions = listOf(primaryOpenAction()),
            )
        engine()
            .at(t0)
            .upsert(draft)
            .gesture(GestureIntent.Tap)
            .expectEffect {
                it is EngineEffect.InvokeAction && it.actionId == "open"
            }
    }

    @Test
    fun `gesture swipe dismiss only when permitted`() {
        val media = media() // not swipeDismissible
        engine()
            .at(t0)
            .upsert(media)
            .gesture(GestureIntent.SwipeDismiss)
            .expectPresent(media.id)
        val n = notification("com.wa")
        engine()
            .at(t0)
            .upsert(n)
            .gesture(GestureIntent.SwipeDismiss)
            .expectLifecycle(n.id, dev.island.dynamicisland.core.model.ActivityLifecycle.RETIRING)
            .expectEffect { it is EngineEffect.NotifySourceDismissed }
    }

    @Test
    fun `gesture swipe next rotates deterministically`() {
        val a = custom("a", Priority(400))
        val b = custom("b", Priority(400))
        val scenario =
            engine()
                .at(t0)
                .upsert(a)
                .at(t0)
                .upsert(b)
        val first = scenario.primaryId()
        scenario
            .gesture(GestureIntent.SwipeNext)
            .expectReason(PresentationReason.PRIMARY_SWAP)
        val second = scenario.primaryId()
        assertTrue(first != second)
        scenario.gesture(GestureIntent.SwipeNext).expectPrimaryId(first)
    }

    @Test
    fun `gesture outside tap collapses`() {
        engine()
            .at(t0)
            .upsert(notification("com.wa"))
            .expectUi(IslandUiState.EXPANDED)
            .gesture(GestureIntent.OutsideTap)
            .expectUi(IslandUiState.COMPACT)
            .expectReason(PresentationReason.COLLAPSE_USER)
    }

    @Test
    fun `gesture EnterInteractive illegal from COMPACT`() {
        engine()
            .at(t0)
            .upsert(media())
            .expectUi(IslandUiState.COMPACT)
            .gesture(GestureIntent.EnterInteractive)
            .expectTransitionRejected()
            .expectUi(IslandUiState.COMPACT)
    }

    @Test
    fun `UI state machine illegal transition leaves state unchanged`() {
        // COMPACT -> INTERACTIVE is illegal
        engine()
            .at(t0)
            .upsert(media())
            .gesture(GestureIntent.EnterInteractive)
            .expectTransitionRejected()
            .expectUi(IslandUiState.COMPACT)
    }

    @Test
    fun `IslandStateMachine rejects COMPACT to INTERACTIVE`() {
        assertEquals(null, IslandStateMachine.transition(IslandUiState.COMPACT, IslandUiState.INTERACTIVE))
        assertEquals(
            IslandUiState.EXPANDED,
            IslandStateMachine.transition(IslandUiState.COMPACT, IslandUiState.EXPANDED),
        )
    }

    @Test
    fun `determinism same sequence yields identical presentations`() {
        fun run(): List<dev.island.dynamicisland.core.model.IslandPresentation> {
            val s = engine()
            s.at(t0).upsert(media())
            s.at(t0 + 1.seconds).upsert(notification("com.wa"))
            s.retirePrimary()
            return s.emittedPresentations
        }
        assertEquals(run(), run())
    }

    @Test
    fun `purity reduce twice equal and state unmodified`() {
        val state = EngineState.initial(EngineConfig())
        val event =
            EngineEvent.Intent(
                dev.island.dynamicisland.core.model.ActivityIntent
                    .Upsert(media()),
            )
        val before = state.copy()
        val r1 = ActivityEngine.reduce(state, event, t0)
        val r2 = ActivityEngine.reduce(state, event, t0)
        assertEquals(r1, r2)
        assertEquals(before, state)
        assertTrue(r1.state !== state)
    }

    @Test
    fun `CONTENT_UPDATE never when primary identity changed`() {
        val media = media()
        val notif = notification("com.wa")
        val scenario =
            engine()
                .at(t0)
                .upsert(media)
                .at(t0 + 1.seconds)
                .upsert(notif)
        assertTrue(scenario.result.presentation.reason != PresentationReason.CONTENT_UPDATE)
        assertEquals(PresentationReason.PREEMPT, scenario.result.presentation.reason)
    }

    @Test
    fun `TimeAdvanced is the only TTL trigger`() {
        val config =
            EngineConfig(
                transientExpandedDuration = 100.milliseconds,
                transientCompactDuration = 100.milliseconds,
            )
        val n = notification("com.wa")
        val scenario = engine(config).at(t0).upsert(n)
        // Gesture at later wall time without TimeAdvanced must not expire.
        scenario.at(t0 + 10.seconds).gesture(GestureIntent.OutsideTap)
        scenario.expectPresent(n.id)
        scenario.expectLifecycle(n.id, dev.island.dynamicisland.core.model.ActivityLifecycle.ACTIVE)
    }

    @Test
    fun `secondary is different type with leading glyph`() {
        val media = media()
        val notif = notification("com.wa")
        val scenario =
            engine()
                .at(t0)
                .upsert(media)
                .at(t0 + 1.seconds)
                .upsert(notif)
        assertEquals(media.id, scenario.snapshot.secondaryId)
    }

    @Test
    fun `ActionInvoked emits InvokeAction effect`() {
        val media = media()
        engine()
            .at(t0)
            .upsert(media)
            .gesture(GestureIntent.ActionInvoked(media.id, "open"))
            .expectEffect {
                it is EngineEffect.InvokeAction && it.activityId == media.id && it.actionId == "open"
            }
    }

    @Test
    fun `host dispatch updates presentation snapshot`() {
        val host = ActivityEngineHost(EngineConfig())
        host.dispatch(
            EngineEvent.Intent(
                dev.island.dynamicisland.core.model.ActivityIntent
                    .Upsert(media()),
            ),
            t0,
        )
        assertEquals(
            ActivityType.MEDIA,
            host.presentation.value.primary
                ?.activity
                ?.type,
        )
        assertEquals(
            ActivityType.MEDIA,
            host
                .snapshot()
                .activities.values
                .first()
                .type,
        )
    }
}
