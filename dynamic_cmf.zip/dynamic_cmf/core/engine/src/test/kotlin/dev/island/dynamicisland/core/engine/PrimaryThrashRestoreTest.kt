package dev.island.dynamicisland.core.engine

import dev.island.dynamicisland.core.common.Ids
import dev.island.dynamicisland.core.common.Timestamp
import dev.island.dynamicisland.core.model.ActivityLifecycle
import dev.island.dynamicisland.core.model.ActivityType
import dev.island.dynamicisland.core.model.EngineConfig
import dev.island.dynamicisland.core.model.EngineEffect
import dev.island.dynamicisland.core.model.IslandUiState
import dev.island.dynamicisland.core.model.Persistence
import dev.island.dynamicisland.core.model.PresentationReason
import dev.island.dynamicisland.core.model.Priority
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds

class PrimaryThrashRestoreTest {
    private val t0 = Timestamp(2_000_000)

    @Test
    fun `primary selection strict priority order`() {
        engine()
            .at(t0)
            .upsert(media())
            .at(t0 + 1.seconds)
            .upsert(notification("com.wa"))
            .expectPrimary(ActivityType.NOTIFICATION)
    }

    @Test
    fun `primary critical recency tie-break`() {
        val older = call(id = "older")
        val newer = call(id = "newer")
        engine()
            .at(t0)
            .upsert(older)
            .at(t0 + 1.seconds)
            .upsert(newer)
            .expectPrimaryId(newer.id)
    }

    @Test
    fun `primary ongoing beats transient on equal priority`() {
        val ongoing = custom("og", Priority(600), Persistence.ONGOING)
        val transient = notification("com.x", key = "t").copy(basePriority = Priority(600))
        // First establish ongoing, then transient at same priority — ongoing should win if created earlier
        // Spec: if tie, ONGOING/STICKY beats TRANSIENT; if still tie OLDEST createdAt.
        // Highest priority first — they're equal so ongoing beats transient.
        engine()
            .at(t0)
            .upsert(ongoing)
            .at(t0 + 1.seconds)
            .upsert(transient)
            .expectPrimaryId(ongoing.id)
    }

    @Test
    fun `primary older-wins tie-break for non-critical`() {
        val a = custom("a", Priority(300))
        val b = custom("b", Priority(300))
        engine()
            .at(t0)
            .upsert(a)
            .at(t0 + 1.seconds)
            .upsert(b)
            .expectPrimaryId(a.id)
    }

    @Test
    fun `primary lexicographic final tie-break`() {
        // Same priority, same createdAt (same now), same persistence → id lexicographic.
        val a = custom("aaa", Priority(300))
        val b = custom("zzz", Priority(300))
        // Insert both at same timestamp via sequential upserts at same `at` — createdAt differs by dispatch.
        // Force same createdAt by using one TimeAdvanced then both upserts at identical now... still sequential.
        // Use equal createdAt by crafting: upsert a, then upsert b with same now but a already has earlier createdAt.
        // Lexicographic only when createdAt equal — use two drafts admitted in one... can't.
        // Instead retire and re-admit isn't same. Comparator uses createdAt then id.
        // For true lex tie: two activities with identical createdAt requires same `now` on both.
        // Engine sets createdAt = now on each upsert; two upserts at same `at(t0)` still get same now.
        val scenario =
            engine()
                .at(t0)
                .upsert(a)
                .at(t0)
                .upsert(b)
        // Same createdAt, same priority, same persistence → lower id wins.
        val winner =
            listOf(a, b).minBy { it.id.value }
        scenario.expectPrimaryId(winner.id)
    }

    @Test
    fun `primary DORMANT excluded from selection`() {
        val media = media()
        engine()
            .at(t0)
            .upsert(media)
            .at(t0 + 1.seconds)
            .upsert(notification("com.wa"))
            .expectLifecycle(media.id, ActivityLifecycle.DORMANT)
            .expectPrimary(ActivityType.NOTIFICATION)
    }

    @Test
    fun `primary RETIRING excluded from selection`() {
        val media = media()
        val notif = notification("com.wa")
        engine()
            .at(t0)
            .upsert(media)
            .advanceTo(t0 + 1.seconds)
            .upsert(notif)
            .retire(notif.id)
            .expectLifecycle(notif.id, ActivityLifecycle.RETIRING)
            .expectPrimary(ActivityType.MEDIA)
            .expectReason(PresentationReason.RESTORE)
    }

    @Test
    fun `thrash guard rapid swap deferred`() {
        val config = EngineConfig(thrashGuardWindow = 400.milliseconds)
        val media = media()
        val n1 = notification("com.a", key = "1")
        val n2 = notification("com.b", key = "2", priority = Priority(650))
        engine(config)
            .at(t0)
            .upsert(media)
            .advanceTo(t0 + 500.milliseconds)
            .upsert(n1)
            .expectPrimaryId(n1.id)
            .at(t0 + 550.milliseconds)
            .upsert(n2)
            .expectPrimaryId(n1.id)
            .expectPending(n2.id)
    }

    @Test
    fun `thrash pending re-evaluated not blindly applied`() {
        val config = EngineConfig(thrashGuardWindow = 400.milliseconds)
        val n1 = notification("com.a", key = "1", priority = Priority(600))
        val n2 = notification("com.b", key = "2", priority = Priority(610))
        val call = call()
        engine(config)
            .at(t0)
            .upsert(n1)
            .at(t0 + 10.milliseconds)
            .upsert(n2)
            .expectPending(n2.id)
            .expectPrimaryId(n1.id)
            // Before thrash releases, admit CRITICAL call — recomputation should pick call, not blind n2.
            .at(t0 + 20.milliseconds)
            .upsert(call)
            .expectPrimaryId(call.id)
            .advanceTo(t0 + 500.milliseconds)
            .expectPrimaryId(call.id)
    }

    @Test
    fun `thrash CRITICAL bypasses the guard`() {
        val config = EngineConfig(thrashGuardWindow = 400.milliseconds)
        engine(config)
            .at(t0)
            .upsert(notification("com.a"))
            .at(t0 + 10.milliseconds)
            .upsert(call())
            .expectPrimary(ActivityType.CALL)
            .expectPending(null)
    }

    @Test
    fun `thrash ONGOING_CRITICAL bypasses the guard`() {
        val config = EngineConfig(thrashGuardWindow = 400.milliseconds)
        val nav =
            draft(
                type = ActivityType.NAVIGATION,
                id = Ids.stable("nav", "1"),
                persistence = Persistence.ONGOING,
                autoExpandOnEnter = false,
            )
        engine(config)
            .at(t0)
            .upsert(notification("com.a"))
            .at(t0 + 10.milliseconds)
            .upsert(nav)
            .expectPrimary(ActivityType.NAVIGATION)
            .expectPending(null)
    }

    @Test
    fun `thrash guard releases on time`() {
        val config = EngineConfig(thrashGuardWindow = 400.milliseconds)
        val n1 = notification("com.a", key = "1", priority = Priority(600))
        val n2 = notification("com.b", key = "2", priority = Priority(650))
        engine(config)
            .at(t0)
            .upsert(n1)
            .at(t0 + 10.milliseconds)
            .upsert(n2)
            .expectPrimaryId(n1.id)
            .expectPending(n2.id)
            .advanceTo(t0 + 500.milliseconds)
            .expectPrimaryId(n2.id)
            .expectPending(null)
    }

    @Test
    fun `preempt restore single`() {
        val media = media()
        val notif = notification("com.wa")
        engine()
            .at(t0)
            .upsert(media)
            .advanceTo(t0 + 1.seconds)
            .upsert(notif)
            .expectReason(PresentationReason.PREEMPT)
            .expectRestoreStack(listOf(media.id))
            .retire(notif.id)
            .expectReason(PresentationReason.RESTORE)
            .expectPrimaryId(media.id)
            .expectRestoreStack()
    }

    @Test
    fun `preempt nested restores LIFO order`() {
        val media = media()
        val nav =
            draft(
                type = ActivityType.NAVIGATION,
                id = Ids.stable("nav", "1"),
                persistence = Persistence.ONGOING,
                autoExpandOnEnter = false,
            )
        val notif = notification("com.wa")
        val criticalTransient = notification("com.critical", key = "c", priority = Priority(950))
        engine()
            .at(t0)
            .upsert(media)
            .advanceTo(t0 + 1.seconds)
            .upsert(notif)
            .expectRestoreStack(listOf(media.id))
            .advanceTo(t0 + 2.seconds)
            .upsert(nav)
            .expectPrimaryId(nav.id)
            .expectRestoreStack(listOf(media.id))
            .advanceTo(t0 + 3.seconds)
            .upsert(criticalTransient)
            .expectPrimaryId(criticalTransient.id)
            .expectRestoreStack(listOf(nav.id, media.id))
            .retire(criticalTransient.id)
            .expectPrimaryId(nav.id)
            .expectReason(PresentationReason.RESTORE)
            .expectRestoreStack(listOf(media.id))
    }

    @Test
    fun `preempt stack bounded at depth`() {
        val config = EngineConfig(restoreStackDepth = 1)
        val media = media()
        val nav =
            draft(
                type = ActivityType.NAVIGATION,
                id = Ids.stable("nav", "1"),
                persistence = Persistence.ONGOING,
                autoExpandOnEnter = false,
            )
        val notif = notification("com.wa")
        val criticalTransient = notification("com.critical", key = "c", priority = Priority(950))
        engine(config)
            .at(t0)
            .upsert(media)
            .advanceTo(t0 + 1.seconds)
            .upsert(notif)
            .expectRestoreStack(listOf(media.id))
            .advanceTo(t0 + 2.seconds)
            .upsert(nav)
            .advanceTo(t0 + 3.seconds)
            .upsert(criticalTransient)
            // Depth 1: nav push drops media from the bottom.
            .expectRestoreStack(listOf(nav.id))
    }

    @Test
    fun `preempt stale entry skipped on restore`() {
        val media = media()
        val notif = notification("com.wa")
        engine()
            .at(t0)
            .upsert(media)
            .at(t0 + 1.seconds)
            .upsert(notif)
            .expectRestoreStack(listOf(media.id))
            .retire(media.id)
            .expectRestoreStack()
            .retire(notif.id)
            .expectPrimary(null)
    }

    @Test
    fun `preempt retire removes from stack`() {
        val media = media()
        val notif = notification("com.wa")
        val scenario =
            engine()
                .at(t0)
                .upsert(media)
                .at(t0 + 1.seconds)
                .upsert(notif)
                .retire(media.id)
        assertTrue(media.id !in scenario.snapshot.restoreStack)
    }

    @Test
    fun `preempt no duplicate entries`() {
        val media = media()
        val n1 = notification("com.a", key = "1")
        engine()
            .at(t0)
            .upsert(media)
            .at(t0 + 1.seconds)
            .upsert(n1)
            .expectRestoreStack(listOf(media.id))
            .retire(n1.id)
            .exitComplete(n1.id)
            .expectPrimaryId(media.id)
            .at(t0 + 2.seconds)
            .upsert(notification("com.b", key = "2"))
            .expectRestoreStack(listOf(media.id))
    }

    @Test
    fun `TTL transient expires via TimeAdvanced`() {
        val config =
            EngineConfig(
                transientExpandedDuration = 1.seconds,
                transientCompactDuration = 1.seconds,
            )
        val n = notification("com.wa")
        engine(config)
            .at(t0)
            .upsert(n)
            .advanceTo(t0 + 2.seconds)
            .expectLifecycle(n.id, ActivityLifecycle.RETIRING)
    }

    @Test
    fun `retirement ExitAnimationComplete removes activity`() {
        val n = notification("com.wa")
        engine()
            .at(t0)
            .upsert(n)
            .retire(n.id)
            .exitComplete(n.id)
            .expectAbsent(n.id)
            .expectUi(IslandUiState.DORMANT)
    }

    @Test
    fun `retirement watchdog force-removes after timeout`() {
        val config = EngineConfig(exitAnimationTimeout = 600.milliseconds)
        val n = notification("com.wa")
        engine(config)
            .at(t0)
            .upsert(n)
            .retire(n.id)
            .advanceTo(t0 + 700.milliseconds)
            .expectAbsent(n.id)
            .expectWatchdog(listOf(n.id))
    }

    @Test
    fun `ScheduleWake emitted on retire for exit watchdog`() {
        val n = notification("com.wa")
        engine()
            .at(t0)
            .upsert(n)
            .retire(n.id)
            .expectEffect { it is EngineEffect.RequestExitAnimation }
            .expectEffect { it is EngineEffect.ScheduleWake }
    }
}
