plugins {
    alias(libs.plugins.island.jvm.library)
}

dependencies {
    api(project(":core:common"))
    testImplementation(testFixtures(project(":core:common")))
}
