package dev.island.dynamicisland.core.model

public data class ActivityAction(
    public val id: String,
    public val label: String,
    public val glyph: GlyphId?,
    public val kind: ActionKind,
    public val isPrimary: Boolean,
    public val requiresInteractiveState: Boolean,
)

public enum class ActionKind {
    PLAY_PAUSE,
    NEXT,
    PREVIOUS,
    ANSWER,
    DECLINE,
    HANGUP,
    MUTE,
    SPEAKER,
    REPLY,
    MARK_READ,
    OPEN,
    DISMISS,
    PAUSE_TIMER,
    ADD_MINUTE,
    STOP,
    CUSTOM,
}

public data class InteractionModel(
    public val tappable: Boolean,
    public val expandable: Boolean,
    public val swipeDismissible: Boolean,
    public val longPressable: Boolean,
    public val autoExpandOnEnter: Boolean,
)
