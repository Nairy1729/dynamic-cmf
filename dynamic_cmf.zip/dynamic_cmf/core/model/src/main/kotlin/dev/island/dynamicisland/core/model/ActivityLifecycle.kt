package dev.island.dynamicisland.core.model

public enum class ActivityLifecycle {
    PROPOSED,
    ACTIVE,
    DORMANT,
    RETIRING,
    RETIRED,
}
