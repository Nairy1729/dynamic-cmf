package dev.island.dynamicisland.core.model

public sealed interface ActivitySource {
    public val key: String
    public val packageName: String?

    public data class Notification(
        public val pkg: String,
        public val channelId: String?,
        public val notifKey: String,
    ) : ActivitySource {
        override val key: String = "notif:$pkg:$notifKey"
        override val packageName: String? = pkg
    }

    public data class MediaSession(
        public val pkg: String,
        public val sessionToken: String,
    ) : ActivitySource {
        override val key: String = "media:$pkg:$sessionToken"
        override val packageName: String? = pkg
    }

    public data object Telecom : ActivitySource {
        override val key: String = "telecom"
        override val packageName: String? = null
    }

    public data object System : ActivitySource {
        override val key: String = "system"
        override val packageName: String? = null
    }

    public data class Internal(
        public val tag: String,
    ) : ActivitySource {
        override val key: String = "internal:$tag"
        override val packageName: String? = null
    }
}
