package dev.island.dynamicisland.core.model

public enum class ActivityType {
    CALL,
    ALARM,
    TIMER,
    STOPWATCH,
    MEDIA,
    NAVIGATION,
    RECORDING_SCREEN,
    RECORDING_VOICE,
    CHARGING,
    BATTERY,
    BLUETOOTH,
    DOWNLOAD,
    NOTIFICATION,
    CUSTOM,
}
