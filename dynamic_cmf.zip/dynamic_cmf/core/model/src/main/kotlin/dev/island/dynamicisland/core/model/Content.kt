package dev.island.dynamicisland.core.model

import dev.island.dynamicisland.core.common.Timestamp

public data class CompactContent(
    public val leading: Glyph?,
    public val trailing: TrailingContent?,
    public val accessibilityLabel: String,
)

public sealed interface TrailingContent {
    public data class Text(
        public val value: String,
    ) : TrailingContent

    public data class Countdown(
        public val endsAt: Timestamp,
    ) : TrailingContent

    public data class Elapsed(
        public val startedAt: Timestamp,
    ) : TrailingContent

    public data class Progress(
        public val fraction: Float,
    ) : TrailingContent {
        init {
            require(fraction in 0f..1f) { "Progress.fraction must be in 0f..1f, was $fraction" }
        }
    }

    public data class Level(
        public val percent: Int,
    ) : TrailingContent {
        init {
            require(percent in 0..100) { "Level.percent must be in 0..100, was $percent" }
        }
    }

    public data object Pulse : TrailingContent

    public data class Glyphic(
        public val glyph: Glyph,
    ) : TrailingContent
}

public data class ExpandedContent(
    public val title: String,
    public val subtitle: String?,
    public val body: String?,
    public val media: MediaRef?,
    public val detail: DetailContent?,
    public val accessibilityLabel: String,
)

public sealed interface DetailContent {
    public data class Playback(
        public val positionMs: Long?,
        public val durationMs: Long?,
        public val isPlaying: Boolean,
    ) : DetailContent

    public data class CallState(
        public val startedAt: Timestamp?,
        public val phase: CallPhase,
    ) : DetailContent

    public data class TimerState(
        public val endsAt: Timestamp?,
        public val isPaused: Boolean,
    ) : DetailContent

    public data class ProgressState(
        public val fraction: Float?,
        public val indeterminate: Boolean,
    ) : DetailContent {
        init {
            if (fraction != null) {
                require(fraction in 0f..1f) { "ProgressState.fraction must be in 0f..1f, was $fraction" }
            }
        }
    }

    public data class BatteryState(
        public val percent: Int,
        public val isCharging: Boolean,
        public val wattage: Float?,
    ) : DetailContent {
        init {
            require(percent in 0..100) { "BatteryState.percent must be in 0..100, was $percent" }
        }
    }

    public data class Conversation(
        public val messages: List<MessageLine>,
    ) : DetailContent
}

public enum class CallPhase {
    INCOMING,
    OUTGOING,
    ACTIVE,
    HELD,
    ENDED,
}

public data class MessageLine(
    public val sender: String,
    public val text: String,
    public val at: Timestamp,
)
