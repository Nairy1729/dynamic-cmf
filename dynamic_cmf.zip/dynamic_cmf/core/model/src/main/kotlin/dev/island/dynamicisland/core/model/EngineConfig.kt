package dev.island.dynamicisland.core.model

import kotlin.time.Duration
import kotlin.time.Duration.Companion.milliseconds
import kotlin.time.Duration.Companion.seconds

public data class EngineConfig(
    public val transientExpandedDuration: Duration = 2.6.seconds,
    public val transientCompactDuration: Duration = 3.seconds,
    public val ongoingAutoCollapseDelay: Duration = 4.seconds,
    public val thrashGuardWindow: Duration = 400.milliseconds,
    public val exitAnimationTimeout: Duration = 600.milliseconds,
    public val rateLimitWindow: Duration = 60.seconds,
    public val rateLimitMaxPerPackage: Int = 3,
    public val restoreStackDepth: Int = 4,
    public val maxQueuedActivities: Int = 12,
    public val basePriorities: Map<ActivityType, Priority> = DEFAULT_BASE_PRIORITIES,
    public val userPriorityDeltas: Map<ActivityType, Int> = emptyMap(),
    public val disabledTypes: Set<ActivityType> = emptySet(),
    public val blockedPackages: Set<String> = emptySet(),
    public val alwaysAllowPackages: Set<String> = emptySet(),
    public val suppressTransientsInCall: Boolean = true,
    public val suppressTransientsWhileScreenOff: Boolean = true,
    public val suppressTransientsWhileCameraActive: Boolean = true,
) {
    public companion object {
        /**
         * Canonical base priorities. CALL uses the incoming-call default (950);
         * adapters raise/lower CALL and TIMER completion via [ActivityDraft.basePriority].
         * The engine never inspects [DetailContent] to decide priority.
         */
        public val DEFAULT_BASE_PRIORITIES: Map<ActivityType, Priority> =
            mapOf(
                ActivityType.CALL to Priority(950),
                ActivityType.ALARM to Priority(960),
                ActivityType.TIMER to Priority(400),
                ActivityType.STOPWATCH to Priority(380),
                ActivityType.MEDIA to Priority(420),
                ActivityType.NAVIGATION to Priority(760),
                ActivityType.RECORDING_SCREEN to Priority(780),
                ActivityType.RECORDING_VOICE to Priority(770),
                ActivityType.CHARGING to Priority(560),
                ActivityType.BATTERY to Priority(260),
                ActivityType.BLUETOOTH to Priority(540),
                ActivityType.DOWNLOAD to Priority(360),
                ActivityType.NOTIFICATION to Priority(600),
                ActivityType.CUSTOM to Priority(300),
            )

        /** Documented TIMER completion base priority for adapters. */
        public val TIMER_COMPLETION: Priority = Priority(940)
    }

    /** Documented CALL phase base priorities for adapters. */
    public object CallBases {
        public val INCOMING: Priority = Priority(950)
        public val ACTIVE_OR_HELD: Priority = Priority(820)
        public val ENDED: Priority = Priority(520)
    }
}
