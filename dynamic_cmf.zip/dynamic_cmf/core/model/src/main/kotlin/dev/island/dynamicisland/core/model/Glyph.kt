package dev.island.dynamicisland.core.model

public enum class GlyphId {
    PLAY,
    PAUSE,
    MUSIC,
    PHONE,
    PHONE_MISSED,
    BOLT,
    BATTERY,
    TIMER,
    STOPWATCH,
    MIC,
    SCREEN_RECORD,
    BLUETOOTH,
    DOWNLOAD,
    NAVIGATION,
    BELL,
    MESSAGE,
    ALARM,
    CHECK,
    WARNING,
    APP,
}

public data class Glyph(
    public val id: GlyphId,
    public val tint: AccentRef? = null,
)

public data class MediaRef(
    public val key: String,
)

public sealed interface AccentRef {
    public data object Default : AccentRef

    public data class FromSource(
        public val sourceKey: String,
    ) : AccentRef

    public data class Fixed(
        public val argb: Long,
    ) : AccentRef
}
