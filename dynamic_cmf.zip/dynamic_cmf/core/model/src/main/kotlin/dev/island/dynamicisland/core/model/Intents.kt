package dev.island.dynamicisland.core.model

import dev.island.dynamicisland.core.common.ActivityId
import dev.island.dynamicisland.core.common.Timestamp

public sealed interface ActivityIntent {
    public data class Upsert(
        public val activity: ActivityDraft,
    ) : ActivityIntent

    public data class Retire(
        public val id: ActivityId,
        public val reason: RetireReason,
    ) : ActivityIntent

    public data class RetireBySource(
        public val source: ActivitySource,
        public val reason: RetireReason,
    ) : ActivityIntent

    public data class RetireByType(
        public val type: ActivityType,
        public val reason: RetireReason,
    ) : ActivityIntent

    public data object ClearAll : ActivityIntent
}

public sealed interface GestureIntent {
    public data object Tap : GestureIntent

    public data object LongPress : GestureIntent

    public data object OutsideTap : GestureIntent

    public data object SwipeDismiss : GestureIntent

    public data object SwipeNext : GestureIntent

    public data object SwipePrevious : GestureIntent

    public data class ExpandRequest(
        public val userInitiated: Boolean,
    ) : GestureIntent

    public data class CollapseRequest(
        public val userInitiated: Boolean,
    ) : GestureIntent

    public data object EnterInteractive : GestureIntent

    public data object ExitInteractive : GestureIntent

    public data class TouchHold(
        public val isHeld: Boolean,
    ) : GestureIntent

    public data class ActionInvoked(
        public val activityId: ActivityId,
        public val actionId: String,
    ) : GestureIntent
}

public sealed interface EngineEvent {
    public data class Intent(
        public val intent: ActivityIntent,
    ) : EngineEvent

    public data class Gesture(
        public val gesture: GestureIntent,
    ) : EngineEvent

    public data class TimeAdvanced(
        public val now: Timestamp,
    ) : EngineEvent

    public data class ExitAnimationComplete(
        public val id: ActivityId,
    ) : EngineEvent

    public data class ConfigChanged(
        public val config: EngineConfig,
    ) : EngineEvent

    public data class ContextChanged(
        public val context: SystemContext,
    ) : EngineEvent
}

public data class SystemContext(
    public val screenOn: Boolean,
    public val inCall: Boolean,
    public val cameraActive: Boolean,
    public val screenRecording: Boolean,
    public val doNotDisturb: Boolean,
) {
    public companion object {
        public val Default: SystemContext =
            SystemContext(
                screenOn = true,
                inCall = false,
                cameraActive = false,
                screenRecording = false,
                doNotDisturb = false,
            )
    }
}
