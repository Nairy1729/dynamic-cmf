package dev.island.dynamicisland.core.model

import dev.island.dynamicisland.core.common.ActivityId
import dev.island.dynamicisland.core.common.Timestamp

public data class IslandActivity(
    public val id: ActivityId,
    public val type: ActivityType,
    public val source: ActivitySource,
    public val basePriority: Priority,
    public val resolvedPriority: Priority,
    public val lifecycle: ActivityLifecycle,
    public val persistence: Persistence,
    public val createdAt: Timestamp,
    public val updatedAt: Timestamp,
    public val expiresAt: Timestamp?,
    public val compact: CompactContent,
    public val expanded: ExpandedContent?,
    public val interaction: InteractionModel,
    public val actions: List<ActivityAction>,
    public val dedupeKey: String,
    public val revision: Long,
    public val aggregateCount: Int = 1,
) {
    init {
        require(actions.size <= 5) { "actions.size must be <= 5, was ${actions.size}" }
        require(actions.count { it.isPrimary } <= 3) {
            "at most 3 primary actions allowed"
        }
        require(revision >= 0L) { "revision must be >= 0" }
        if (expanded == null) {
            require(!interaction.expandable) {
                "expanded == null implies interaction.expandable == false"
            }
        }
    }
}

/**
 * Adapter-produced activity. Engine-owned fields ([IslandActivity.resolvedPriority], lifecycle,
 * timestamps, revision, aggregateCount) are intentionally absent.
 */
public data class ActivityDraft(
    public val id: ActivityId,
    public val type: ActivityType,
    public val source: ActivitySource,
    public val basePriority: Priority,
    public val persistence: Persistence,
    public val expiresAt: Timestamp?,
    public val compact: CompactContent,
    public val expanded: ExpandedContent?,
    public val interaction: InteractionModel,
    public val actions: List<ActivityAction>,
    public val dedupeKey: String,
) {
    init {
        require(actions.size <= 5) { "actions.size must be <= 5, was ${actions.size}" }
        require(actions.count { it.isPrimary } <= 3) {
            "at most 3 primary actions allowed"
        }
        if (expanded == null) {
            require(!interaction.expandable) {
                "expanded == null implies interaction.expandable == false"
            }
        }
    }
}
