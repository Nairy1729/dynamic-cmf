package dev.island.dynamicisland.core.model

public enum class Persistence {
    TRANSIENT,
    ONGOING,
    STICKY,
}
