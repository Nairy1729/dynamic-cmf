package dev.island.dynamicisland.core.model

import dev.island.dynamicisland.core.common.ActivityId
import dev.island.dynamicisland.core.common.Timestamp

public enum class IslandUiState {
    DORMANT,
    COLLAPSED,
    MINIMAL,
    COMPACT,
    EXPANDED,
    INTERACTIVE,
    DISMISSED,
}

public enum class PresentationReason {
    ENTER,
    EXIT,
    PRIMARY_SWAP,
    CONTENT_UPDATE,
    EXPAND_USER,
    EXPAND_AUTO,
    COLLAPSE_USER,
    COLLAPSE_AUTO,
    PREEMPT,
    RESTORE,
    RECONFIGURE,
    NONE,
}

public data class PresentedActivity(
    public val activity: IslandActivity,
    public val slotRevision: Long,
)

public data class IslandPresentation(
    public val uiState: IslandUiState,
    public val primary: PresentedActivity?,
    public val secondary: PresentedActivity?,
    public val queuedCount: Int,
    public val reason: PresentationReason,
    public val autoCollapseAt: Timestamp?,
    public val interactionEnabled: Boolean,
    public val seq: Long,
) {
    public companion object {
        public val Empty: IslandPresentation =
            IslandPresentation(
                uiState = IslandUiState.DORMANT,
                primary = null,
                secondary = null,
                queuedCount = 0,
                reason = PresentationReason.NONE,
                autoCollapseAt = null,
                interactionEnabled = false,
                seq = 0L,
            )
    }
}

public sealed interface EngineEffect {
    public data class ScheduleWake(
        public val at: Timestamp,
    ) : EngineEffect

    public data object CancelWake : EngineEffect

    public data class RequestExitAnimation(
        public val id: ActivityId,
    ) : EngineEffect

    public data class Haptic(
        public val kind: HapticKind,
    ) : EngineEffect

    public data class InvokeAction(
        public val activityId: ActivityId,
        public val actionId: String,
    ) : EngineEffect

    public data class NotifySourceDismissed(
        public val source: ActivitySource,
    ) : EngineEffect

    public data class Rejected(
        public val source: ActivitySource,
        public val reason: RejectReason,
    ) : EngineEffect
}

public enum class HapticKind {
    LIGHT,
    MEDIUM,
    ALERT,
}
