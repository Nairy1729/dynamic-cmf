package dev.island.dynamicisland.core.model

@JvmInline
public value class Priority(
    public val value: Int,
) : Comparable<Priority> {
    init {
        require(value in 100..1000) { "Priority must be in 100..1000, was $value" }
    }

    public val band: PriorityBand
        get() = PriorityBand.of(value)

    public fun coerceToBand(target: PriorityBand): Priority {
        val coerced = value.coerceIn(target.range.first, target.range.last)
        return Priority(coerced)
    }

    override fun compareTo(other: Priority): Int = value.compareTo(other.value)

    public companion object {
        public fun clamped(value: Int): Priority = Priority(value.coerceIn(100, 1000))
    }
}
