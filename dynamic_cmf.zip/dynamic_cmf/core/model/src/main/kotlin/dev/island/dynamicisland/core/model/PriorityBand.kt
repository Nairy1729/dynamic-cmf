package dev.island.dynamicisland.core.model

public enum class PriorityBand(
    public val range: IntRange,
) {
    AMBIENT(100..299),
    ONGOING_AMBIENT(300..499),
    TRANSIENT_ALERT(500..699),
    ONGOING_CRITICAL(700..899),
    CRITICAL(900..1000),
    ;

    public companion object {
        public fun of(value: Int): PriorityBand {
            for (band in entries) {
                if (value in band.range) return band
            }
            error("Priority value $value is outside 100..1000")
        }
    }
}
