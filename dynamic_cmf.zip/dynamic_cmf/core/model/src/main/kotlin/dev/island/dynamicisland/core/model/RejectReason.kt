package dev.island.dynamicisland.core.model

public enum class RejectReason {
    LOW_IMPORTANCE,
    BLOCKED_PACKAGE,
    RATE_LIMITED,
    DUPLICATE,
    QUIET_CONTEXT,
    TYPE_DISABLED,
    MALFORMED,
}
