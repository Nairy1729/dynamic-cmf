package dev.island.dynamicisland.core.model

public enum class RetireReason {
    EXPIRED,
    SOURCE_ENDED,
    SUPERSEDED,
    USER_DISMISSED,
    POLICY_REJECTED,
    CLEARED,
}
