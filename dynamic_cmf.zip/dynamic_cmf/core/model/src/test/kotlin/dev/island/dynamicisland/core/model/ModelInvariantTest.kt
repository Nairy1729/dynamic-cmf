package dev.island.dynamicisland.core.model

import dev.island.dynamicisland.core.common.ActivityId
import dev.island.dynamicisland.core.common.Timestamp
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertThrows
import org.junit.jupiter.api.Test

class ModelInvariantTest {
    @Test
    fun `priority rejects out of range`() {
        assertThrows(IllegalArgumentException::class.java) { Priority(99) }
        assertThrows(IllegalArgumentException::class.java) { Priority(1001) }
        assertEquals(PriorityBand.CRITICAL, Priority(950).band)
    }

    @Test
    fun `progress fraction validated`() {
        assertThrows(IllegalArgumentException::class.java) {
            TrailingContent.Progress(1.1f)
        }
    }

    @Test
    fun `island activity rejects expandable without expanded`() {
        assertThrows(IllegalArgumentException::class.java) {
            IslandActivity(
                id = ActivityId("x"),
                type = ActivityType.MEDIA,
                source = ActivitySource.System,
                basePriority = Priority(420),
                resolvedPriority = Priority(420),
                lifecycle = ActivityLifecycle.ACTIVE,
                persistence = Persistence.ONGOING,
                createdAt = Timestamp(0),
                updatedAt = Timestamp(0),
                expiresAt = null,
                compact = CompactContent(null, null, "a"),
                expanded = null,
                interaction =
                    InteractionModel(
                        tappable = true,
                        expandable = true,
                        swipeDismissible = false,
                        longPressable = false,
                        autoExpandOnEnter = false,
                    ),
                actions = emptyList(),
                dedupeKey = "k",
                revision = 0,
            )
        }
    }

    @Test
    fun `default base priorities match the table`() {
        val p = EngineConfig.DEFAULT_BASE_PRIORITIES
        assertEquals(950, p.getValue(ActivityType.CALL).value)
        assertEquals(960, p.getValue(ActivityType.ALARM).value)
        assertEquals(400, p.getValue(ActivityType.TIMER).value)
        assertEquals(940, EngineConfig.TIMER_COMPLETION.value)
        assertEquals(820, EngineConfig.CallBases.ACTIVE_OR_HELD.value)
    }
}
